import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonList,
  IonItem,
  IonLabel,
  IonImg
} from '@ionic/angular';

import { Publicacion } from '../../models/publicacion';
import { PublicacionesService } from '../../services/publicaciones.service';


@Component({
  selector: 'app-publicaciones',
  templateUrl: './publicaciones.page.html',
  styleUrls: ['./publicaciones.page.scss'],
  imports: [
    CommonModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonButton,
    IonList,
    IonItem,
    IonLabel,
    IonImg,
    RouterLink
  ]
})
export class PublicacionesPage implements OnInit {


  publicaciones: Publicacion[] = [];


  constructor(
    private publicacionesService: PublicacionesService
  ) {}


  async ngOnInit() {

    await this.cargarPublicaciones();

  }



  async ionViewWillEnter(){

    await this.cargarPublicaciones();

  }



  async cargarPublicaciones(){

    this.publicaciones =
      await this.publicacionesService.obtenerPublicaciones();

  }



  async eliminar(id:number){

    await this.publicacionesService.eliminarPublicacion(id);

    await this.cargarPublicaciones();

  }


}