import { Component, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';


import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonItem,
  IonInput,
  IonTextarea,
  IonButton,
  IonImg
} from '@ionic/angular';


import { PublicacionesService } from '../../services/publicaciones.service';



@Component({
  selector: 'app-nueva-publicacion',
  templateUrl: './nueva-publicacion.page.html',
  styleUrls: ['./nueva-publicacion.page.scss'],

  imports: [
    ReactiveFormsModule,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonItem,
    IonInput,
    IonTextarea,
    IonButton,
    IonImg
  ]
})
export class NuevaPublicacionPage {


  formulario: FormGroup;


  imagen: string = '';



  @ViewChild('archivoImagen')
  archivoImagen!: ElementRef;



  constructor(

    private fb: FormBuilder,

    private publicacionesService: PublicacionesService,

    private router: Router

  ){


    this.formulario = this.fb.group({


      titulo: [

        '',

        [

          Validators.required,

          Validators.minLength(5)

        ]

      ],



      descripcion: [

        '',

        [

          Validators.required,

          Validators.minLength(20)

        ]

      ]


    });


  }




  seleccionarImagen(){


    this.archivoImagen.nativeElement.click();


  }





  cargarImagen(event:any){


    const archivo = event.target.files[0];



    if(archivo){


      const lector = new FileReader();



      lector.onload = () => {


        this.imagen = lector.result as string;


      };



      lector.readAsDataURL(archivo);


    }


  }






async guardar(){


  console.log('VALIDACION TITULO:',
    this.formulario.value.titulo
  );


  console.log('VALIDACION DESCRIPCION:',
    this.formulario.value.descripcion
  );


  console.log('VALIDACION IMAGEN:',
    this.imagen.length
  );



  if(this.formulario.invalid || !this.imagen){


    alert('ENTRO EN VALIDACION');

    return;


  }




    const aviso = {


      id: Date.now(),


      titulo: this.formulario.value.titulo,


      imagen: this.imagen,


      descripcion: this.formulario.value.descripcion,


      fecha: new Date().toLocaleDateString()


    };





    await this.publicacionesService.guardarPublicacion(aviso);




    this.router.navigate(['/publicaciones']);



  }



}