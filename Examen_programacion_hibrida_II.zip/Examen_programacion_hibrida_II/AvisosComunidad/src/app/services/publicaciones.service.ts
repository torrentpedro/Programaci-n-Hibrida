import { Injectable } from '@angular/core';
import { Preferences } from '@capacitor/preferences';
import { Publicacion } from '../models/publicacion';


@Injectable({
  providedIn: 'root'
})
export class PublicacionesService {

  private clave = 'avisos';


  constructor() { }


  async obtenerPublicaciones(): Promise<Publicacion[]> {

    const datos = await Preferences.get({
      key: this.clave
    });


    if (datos.value) {

      return JSON.parse(datos.value);

    }


    return [];

  }



  async guardarPublicacion(publicacion: Publicacion): Promise<void> {

    const publicaciones = await this.obtenerPublicaciones();


    publicaciones.push(publicacion);


    await Preferences.set({

      key: this.clave,

      value: JSON.stringify(publicaciones)

    });

  }



  async eliminarPublicacion(id: number): Promise<void> {

    const publicaciones = await this.obtenerPublicaciones();


    const resultado = publicaciones.filter(
      aviso => aviso.id !== id
    );


    await Preferences.set({

      key: this.clave,

      value: JSON.stringify(resultado)

    });

  }

}