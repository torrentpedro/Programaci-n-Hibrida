export interface Publicacion {

  id:number;

  titulo:string;

  imagen:string;

  descripcion:string;

  fecha:string;

}