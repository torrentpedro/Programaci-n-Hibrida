import { Routes } from '@angular/router';

export const routes: Routes = [

  {
    path: 'publicaciones',
    loadComponent: () =>
      import('./pages/publicaciones/publicaciones.page')
      .then(m => m.PublicacionesPage)
  },

  {
    path: 'nueva-publicacion',
    loadComponent: () =>
      import('./pages/nueva-publicacion/nueva-publicacion.page')
      .then(m => m.NuevaPublicacionPage)
  },

  {
    path: '',
    redirectTo: 'publicaciones',
    pathMatch: 'full'
  }

];
