import { Component, EventEmitter, Input, Output } from '@angular/core';

import {

  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonButton

} from '@ionic/angular';


import { NgIf } from '@angular/common';

import { Quote } from '../../models/quote';


@Component({

  selector: 'app-quote-card',

  standalone:true,

  imports:[

    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonButton,
    NgIf

  ],

  templateUrl:'./quote-card.component.html',

  styleUrl:'./quote-card.component.scss'

})


export class QuoteCardComponent {


  @Input()
  quote!: Quote;


  @Input()
  permitirEliminar = true;


  @Output()
  delete = new EventEmitter<number>();



  eliminar(){

    this.delete.emit(
      this.quote.id
    );

  }


}