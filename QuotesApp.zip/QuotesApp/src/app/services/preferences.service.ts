import { Injectable } from '@angular/core';

import { Preferences } from '@capacitor/preferences';



@Injectable({

  providedIn: 'root'

})


export class PreferencesService {



  private readonly claveEliminar = 'permitirEliminar';





  constructor() {}






  async guardarPermitirEliminar(valor:boolean): Promise<void> {



    await Preferences.set({

      key: this.claveEliminar,

      value: valor.toString()


    });



  }








  async obtenerPermitirEliminar(): Promise<boolean> {



    const resultado = await Preferences.get({

      key: this.claveEliminar


    });





    if(resultado.value === null){


      return false;


    }






    return resultado.value === 'true';



  }






}