import { Injectable } from '@angular/core';

import {
  CapacitorSQLite,
  SQLiteConnection,
  SQLiteDBConnection
} from '@capacitor-community/sqlite';

import { Capacitor } from '@capacitor/core';

import { Quote } from '../models/quote';


@Injectable({
  providedIn: 'root'
})
export class DatabaseService {


  private sqlite: SQLiteConnection;

  private db?: SQLiteDBConnection;

  private dbName = 'quotesdb';

  private initPromise?: Promise<void>;



  constructor() {

    this.sqlite = new SQLiteConnection(
      CapacitorSQLite
    );

  }




  async initDatabase(): Promise<void> {


    if (this.db) {

      return;

    }


    if (this.initPromise) {

      return this.initPromise;

    }


    this.initPromise = this.crearDatabase();


    return this.initPromise;

  }






  private async crearDatabase(): Promise<void> {


    console.log(
      'Inicializando base de datos'
    );



    const platform = Capacitor.getPlatform();



    if (platform === 'web') {


      await customElements.whenDefined(
        'jeep-sqlite'
      );


      const jeepSqlite =
        document.querySelector(
          'jeep-sqlite'
        );


      if (!jeepSqlite) {

        throw new Error(
          'jeep-sqlite no está cargado'
        );

      }



      await this.sqlite.initWebStore();


    }




    const existeConexion =
      await this.sqlite.isConnection(
        this.dbName,
        false
      );





    if (existeConexion.result) {


      this.db =
        await this.sqlite.retrieveConnection(
          this.dbName,
          false
        );


    } else {


      this.db =
        await this.sqlite.createConnection(
          this.dbName,
          false,
          'no-encryption',
          1,
          false
        );


    }




    if (!this.db) {


      throw new Error(
        'No se pudo crear conexión SQLite'
      );


    }




    await this.db.open();






    await this.db.execute(`

      CREATE TABLE IF NOT EXISTS quotes (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        frase TEXT NOT NULL,

        autor TEXT NOT NULL

      );

    `);






    const resultado =
      await this.db.query(`

        SELECT COUNT(*) AS cantidad

        FROM quotes

      `);





    const cantidad =
      resultado.values?.[0]?.['cantidad'] ?? 0;





    if (cantidad === 0) {


      await this.db.run(`

        INSERT INTO quotes
        (frase, autor)

        VALUES

        (
          'La vida es aquello que pasa mientras haces otros planes',
          'John Lennon'
        ),

        (
          'El éxito es la suma de pequeños esfuerzos repetidos cada día',
          'Robert Collier'
        ),

        (
          'El único modo de hacer un gran trabajo es amar lo que haces',
          'Steve Jobs'
        );

      `);


    }





    if (platform === 'web') {

      await this.sqlite.saveToStore(
        this.dbName
      );

    }





    console.log(
      'SQLite abierto correctamente'
    );


  }









  private async asegurarBD(): Promise<void> {


    if (!this.db) {

      await this.initDatabase();

    }




    if (!this.db) {


      throw new Error(
        'Base de datos no disponible'
      );


    }


  }









  async getQuotes(): Promise<Quote[]> {


    await this.asegurarBD();




    const result =
      await this.db!.query(`

        SELECT *

        FROM quotes

        ORDER BY id DESC

      `);




    return result.values as Quote[] ?? [];


  }









  async addQuote(
    quote: Quote
  ): Promise<void> {


    await this.asegurarBD();




    await this.db!.run(`

      INSERT INTO quotes
      (
        frase,
        autor
      )

      VALUES (?,?)

    `,
    [

      quote.frase,

      quote.autor

    ]);




    if (Capacitor.getPlatform() === 'web') {

      await this.sqlite.saveToStore(
        this.dbName
      );

    }


  }









  async deleteQuote(
    id: number
  ): Promise<void> {


    await this.asegurarBD();




    await this.db!.run(`

      DELETE FROM quotes

      WHERE id = ?

    `,
    [

      id

    ]);




    if (Capacitor.getPlatform() === 'web') {

      await this.sqlite.saveToStore(
        this.dbName
      );

    }


  }









  async getNextId(): Promise<number> {


    await this.asegurarBD();




    const result =
      await this.db!.query(`

        SELECT MAX(id) AS maximo

        FROM quotes

      `);




    return (

      result.values?.[0]?.['maximo'] ?? 0

    ) + 1;


  }


}