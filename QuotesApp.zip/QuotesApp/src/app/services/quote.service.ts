import { Injectable } from '@angular/core';


import { DatabaseService } from './database.service';

import { Quote } from '../models/quote';



@Injectable({

  providedIn:'root'

})

export class QuoteService {



  private permitirEliminar=false;





  constructor(

    private databaseService:DatabaseService

  ){}





  async getQuotes():Promise<Quote[]>{



    return await this.databaseService.getQuotes();



  }








  async getCurrentQuote():Promise<Quote | undefined>{



    const citas =

      await this.databaseService.getQuotes();




    return citas[0];


  }








  async getNextQuote():Promise<Quote | undefined>{



    const citas =

      await this.databaseService.getQuotes();





    if(citas.length===0){


      return undefined;


    }





    const posicion = Math.floor(

      Math.random()*citas.length

    );





    return citas[posicion];



  }









  async addQuote(quote:Quote){



    console.log(

      'QuoteService recibe',

      quote

    );





    await this.databaseService.addQuote(

      quote

    );





    console.log(

      'QuoteService terminó'

    );



  }









  async deleteQuote(id:number){



    await this.databaseService.deleteQuote(

      id

    );


  }









  async getNextId():Promise<number>{



    return await this.databaseService.getNextId();



  }








  getPermitirEliminar():boolean{


    return this.permitirEliminar;


  }






  setPermitirEliminar(valor:boolean){


    this.permitirEliminar=valor;


  }





}