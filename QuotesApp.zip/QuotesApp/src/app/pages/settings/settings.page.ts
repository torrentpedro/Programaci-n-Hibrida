import { Component, OnInit } from '@angular/core';

import { CommonModule } from '@angular/common';


import {

  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonItem,
  IonLabel,
  IonToggle

} from '@ionic/angular';



import { FormsModule } from '@angular/forms';


import { PreferencesService } from '../../services/preferences.service';





@Component({

  selector:'app-settings',

  standalone:true,


  imports:[


    CommonModule,

    FormsModule,


    IonHeader,

    IonToolbar,

    IonTitle,

    IonContent,

    IonItem,

    IonLabel,

    IonToggle


  ],


  templateUrl:'./settings.page.html',

  styleUrl:'./settings.page.scss'

})



export class SettingsPage implements OnInit {



  permitirEliminar = false;





  constructor(

    private preferencesService: PreferencesService

  ) {}






  async ngOnInit(){



    this.permitirEliminar =

    await this.preferencesService.obtenerPermitirEliminar();



  }








  async cambiarEliminar(){



    await this.preferencesService.guardarPermitirEliminar(

      this.permitirEliminar

    );



  }




}