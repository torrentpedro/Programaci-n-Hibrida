import { Component, OnInit } from '@angular/core';

import { CommonModule } from '@angular/common';


import {

  IonHeader,

  IonToolbar,

  IonTitle,

  IonContent,

  IonButton

} from '@ionic/angular';



import { QuoteService } from '../../services/quote.service';

import { Quote } from '../../models/quote';


import { QuoteCardComponent } 
from '../../components/quote-card/quote-card.component';





@Component({

  selector:'app-home',

  standalone:true,


  imports:[


    CommonModule,


    IonHeader,

    IonToolbar,

    IonTitle,

    IonContent,

    IonButton,


    QuoteCardComponent


  ],



  templateUrl:'./home.page.html',

  styleUrl:'./home.page.scss'

})



export class HomePage implements OnInit {



  quote?: Quote;






  constructor(

    private quoteService: QuoteService

  ){}





  async ngOnInit(){


    await this.cargarCitaActual();


  }







  async ionViewWillEnter(){


    await this.cargarCitaActual();


  }







  async cargarCitaActual(){



    const cita = 

    await this.quoteService.getCurrentQuote();



    if(cita){


      this.quote = cita;


    }



  }







  async siguienteCita(){



    const cita =

    await this.quoteService.getNextQuote();




    if(cita){


      this.quote = cita;


    }



  }







}