import { Component, OnInit } from '@angular/core';

import { CommonModule } from '@angular/common';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonButton,
  IonItem,
  IonLabel,
  IonInput
} from '@ionic/angular';


import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule
} from '@angular/forms';


import { QuoteService } from '../../services/quote.service';

import { PreferencesService } from '../../services/preferences.service';

import { Quote } from '../../models/quote';


import { QuoteCardComponent } from '../../components/quote-card/quote-card.component';



@Component({

  selector:'app-quotes',

  standalone:true,

  imports:[

    CommonModule,

    ReactiveFormsModule,

    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonButton,
    IonItem,
    IonLabel,
    IonInput,

    QuoteCardComponent

  ],

  templateUrl:'./quotes.page.html',

  styleUrl:'./quotes.page.scss'

})

export class QuotesPage implements OnInit {



  quotes:Quote[]=[];


  permitirEliminar=false;


  quoteForm!:FormGroup;





  constructor(

    private quoteService:QuoteService,

    private preferencesService:PreferencesService,

    private fb:FormBuilder

  ){}





  ngOnInit(){


    this.quoteForm = this.fb.group({


      frase:[

        '',

        [

          Validators.required,

          Validators.minLength(5)

        ]

      ],



      autor:[

        '',

        [

          Validators.required,

          Validators.minLength(2)

        ]

      ]



    });



  }







  async ionViewWillEnter(){


    await this.cargarCitas();


    this.permitirEliminar =

      await this.preferencesService.obtenerPermitirEliminar();


  }







  async cargarCitas(){


    this.quotes =

      await this.quoteService.getQuotes();



    console.log(

      'CITAS ACTUALES',

      this.quotes

    );


  }








  async agregarCita(){



    if(this.quoteForm.invalid){


      this.quoteForm.markAllAsTouched();


      return;


    }







    const nueva:Quote={


      id:

      await this.quoteService.getNextId(),



      frase:

      this.quoteForm.value.frase,



      autor:

      this.quoteForm.value.autor



    };






    console.log(

      'ANTES DE GUARDAR',

      nueva

    );






    try{



      await this.quoteService.addQuote(

        nueva

      );





      console.log(

        'GUARDADO SQLITE'

      );





      this.quoteForm.reset();





      await this.cargarCitas();





      console.log(

        'LISTA ACTUALIZADA',

        this.quotes

      );



    }

    catch(error){



      console.error(

        'ERROR GUARDANDO',

        error

      );



    }



  }









  async eliminarCita(id:number){



    await this.quoteService.deleteQuote(

      id

    );



    await this.cargarCitas();



  }





}