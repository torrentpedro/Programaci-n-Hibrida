export interface Quote {

  id: number;

  frase: string;

  autor: string;

}