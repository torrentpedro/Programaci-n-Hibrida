import { Component, EventEmitter, Input, Output } from '@angular/core';

import { NgIf } from '@angular/common';


import {

  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonButton

} from '@ionic/angular';


import { Quote } from '../../models/quote';



@Component({

  selector:'app-quote-card',

  standalone:true,


  imports:[

    NgIf,

    IonCard,

    IonCardHeader,

    IonCardTitle,

    IonCardContent,

    IonButton

  ],


  templateUrl:'./quote-card.component.html',

  styleUrl:'./quote-card.component.scss'

})


export class QuoteCardComponent {



  @Input()

  quote!: Quote;





  @Input()

  mostrarEliminar = false;





  @Output()

  delete = new EventEmitter<number>();






  eliminar(){


    this.delete.emit(

      this.quote.id

    );


  }



}