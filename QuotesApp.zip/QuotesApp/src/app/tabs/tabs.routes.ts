import { Routes } from '@angular/router';

import { TabsPage } from './tabs.page';

export const routes: Routes = [

  {
    path: 'tabs',
    component: TabsPage,

    children: [

      {
        path: 'home',
        loadComponent: () =>
          import('../pages/home/home.page')
          .then((m) => m.HomePage),
      },

      {
        path: 'quotes',
        loadComponent: () =>
          import('../pages/quotes/quotes.page')
          .then((m) => m.QuotesPage),
      },

      {
        path: 'settings',
        loadComponent: () =>
          import('../pages/settings/settings.page')
          .then((m) => m.SettingsPage),
      },

      {
        path: '',
        redirectTo: '/tabs/home',
        pathMatch: 'full',
      },

    ],
  },

  {
    path: '',
    redirectTo: '/tabs/home',
    pathMatch: 'full',
  },

];
