//#region node_modules/@ionic/core/components/p-ZjP4CjeZ.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var d = "undefined" != typeof window ? window : void 0;
var o = "undefined" != typeof document ? document : void 0;
//#endregion
export { o as n, d as t };
