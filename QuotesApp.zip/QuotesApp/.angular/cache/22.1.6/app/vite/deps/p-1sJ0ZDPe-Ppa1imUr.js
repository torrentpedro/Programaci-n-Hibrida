//#region node_modules/@ionic/core/components/p-1sJ0ZDPe.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var t = class {
	constructor() {
		this.m = /* @__PURE__ */ new Map();
	}
	reset(t) {
		this.m = new Map(Object.entries(t));
	}
	get(t, n) {
		const e = this.m.get(t);
		return void 0 !== e ? e : n;
	}
	getBoolean(t, n = !1) {
		const e = this.m.get(t);
		return void 0 === e ? n : "string" == typeof e ? "true" === e : !!e;
	}
	getNumber(t, n) {
		const e = parseFloat(this.m.get(t));
		return isNaN(e) ? void 0 !== n ? n : NaN : e;
	}
	set(t, n) {
		this.m.set(t, n);
	}
};
var n = new t();
var e = (t) => {
	try {
		const n = t.sessionStorage.getItem(r);
		return null !== n ? JSON.parse(n) : {};
	} catch {
		return {};
	}
};
var o = (t, n) => {
	try {
		t.sessionStorage.setItem(r, JSON.stringify(n));
	} catch {
		return;
	}
};
var s = (t) => {
	const n = {};
	return t.location.search.slice(1).split("&").map(((t) => t.split("="))).map((([t, n]) => {
		try {
			return [decodeURIComponent(t), decodeURIComponent(n)];
		} catch {
			return ["", ""];
		}
	})).filter((([t]) => l(t, i))).map((([t, n]) => [t.slice(i.length), n])).forEach((([t, e]) => {
		n[t] = e;
	})), n;
};
var l = (t, n) => t.substr(0, n.length) === n;
var i = "ionic:";
var r = "ionic-persist-config";
var c;
(function(t) {
	t.OFF = "OFF", t.ERROR = "ERROR", t.WARN = "WARN", t.DEBUG = "DEBUG";
})(c || (c = {}));
var u = {
	[c.OFF]: 0,
	[c.ERROR]: 1,
	[c.WARN]: 2,
	[c.DEBUG]: 3
};
var f = (t) => {
	return u[String(n.get("logLevel", c.WARN)).toUpperCase()] >= u[t];
};
var a = (t, ...n) => {
	if (f(c.WARN)) return console.warn(`[Ionic Warning]: ${t}`, ...n);
};
var d = (t, ...n) => {
	if (f(c.ERROR)) return console.error(`[Ionic Error]: ${t}`, ...n);
};
var h = (t, ...n) => console.error(`<${t.tagName.toLowerCase()}> must be used inside ${n.join(" or ")}.`);
var v = { isBrowser: !0 };
var p = ((t) => (t.Undefined = "undefined", t.Null = "null", t.String = "string", t.Number = "number", t.SpecialNumber = "number", t.Boolean = "boolean", t.BigInt = "bigint", t))(p || {});
var $ = ((t) => (t.Array = "array", t.Date = "date", t.Map = "map", t.Object = "object", t.RegularExpression = "regexp", t.Set = "set", t.Channel = "channel", t.Symbol = "symbol", t))($ || {});
var b = "type";
var g = "value";
var m = "serialized:";
function y(t, n, e) {
	const o = "undefined" != typeof HTMLElement ? HTMLElement.prototype : null;
	for (; t && t !== o;) {
		const o = Object.getOwnPropertyDescriptor(t, n);
		if (o && (!e || o.get)) return o;
		t = Object.getPrototypeOf(t);
	}
}
var w;
var j = (t, n) => {
	var e;
	Object.entries(null != (e = n.o.t) ? e : {}).map((([e, [o]]) => {
		if (31 & o || 32 & o) {
			const o = t[e], s = y(Object.getPrototypeOf(t), e, !0) || Object.getOwnPropertyDescriptor(t, e);
			s && Object.defineProperty(t, e, {
				get() {
					return s.get.call(this);
				},
				set(t) {
					s.set.call(this, t);
				},
				configurable: !0,
				enumerable: !0
			}), n.l.has(e) ? t[e] = n.l.get(e) : void 0 !== o && (t[e] = o);
		}
	}));
};
var O = (t) => {
	if (t.__stencil__getHostRef) return t.__stencil__getHostRef();
};
var N = (t, n) => n in t;
var S = (t, n) => (0, console.error)(t, n);
var x = /* @__PURE__ */ new Map();
var E = [];
var k = "s-id";
var C = "sty-id";
var M = "c-id";
var I = "http://www.w3.org/1999/xlink";
var R = "undefined" != typeof window ? window : {};
var A = R.HTMLElement || class {};
var L = {
	i: 0,
	u: "",
	jmp: (t) => t(),
	raf: (t) => requestAnimationFrame(t),
	ael: (t, n, e, o) => t.addEventListener(n, e, o),
	rel: (t, n, e, o) => t.removeEventListener(n, e, o),
	ce: (t, n) => new CustomEvent(t, n)
};
var B = (() => {
	var t;
	let n = !1;
	try {
		null == (t = R.document) || t.addEventListener("e", null, Object.defineProperty({}, "passive", { get() {
			n = !0;
		} }));
	} catch (t) {}
	return n;
})();
var _ = (() => {
	try {
		return !!R.document.adoptedStyleSheets && (new CSSStyleSheet(), "function" == typeof new CSSStyleSheet().replaceSync);
	} catch (t) {}
	return !1;
})();
var T = !!_ && (() => !!R.document && Object.getOwnPropertyDescriptor(R.document.adoptedStyleSheets, "length").writable)();
var F = !1;
var U = [];
var D = [];
var W = () => {
	var t;
	return (null == (t = R.document) ? void 0 : t.hidden) ? q(P) : L.raf(P);
};
var V = (t, n) => (e) => {
	t.push(e), F || (F = !0, n && 4 & L.i ? q(P) : W());
};
var H = (t) => {
	for (let n = 0; n < t.length; n++) try {
		t[n](performance.now());
	} catch (t) {
		S(t);
	}
	t.length = 0;
};
var P = () => {
	H(U), H(D), (F = U.length > 0) && W();
};
var q = (t) => Promise.resolve(void 0).then(t);
var z = V(U, !1);
var J = V(D, !0);
var Y = (t) => {
	const n = new URL(t, L.u);
	return n.origin !== R.location.origin ? n.href : n.pathname;
};
function Z(t) {
	const n = { mode: "open" };
	n.delegatesFocus = !!(16 & t.i);
	const e = this.attachShadow(n);
	void 0 === w && (w = null), w && (T ? e.adoptedStyleSheets.push(w) : e.adoptedStyleSheets = [...e.adoptedStyleSheets, w]);
}
var K = (t) => {
	const n = xt(t, "childNodes");
	t.tagName && t.tagName.includes("-") && t["s-cr"] && "SLOT-FB" !== t.tagName && X(n, t.tagName).forEach(((t) => {
		1 === t.nodeType && "SLOT-FB" === t.tagName && (t.hidden = !!tt(t, ot(t), !1).length);
	}));
	let e = 0;
	for (e = 0; e < n.length; e++) {
		const t = n[e];
		1 === t.nodeType && xt(t, "childNodes").length && K(t);
	}
};
var Q = (t) => {
	const n = [];
	for (let e = 0; e < t.length; e++) {
		const o = t[e]["s-nr"] || void 0;
		o && o.isConnected && n.push(o);
	}
	return n;
};
function X(t, n, e) {
	let o, s = 0, l = [];
	for (; s < t.length; s++) {
		if (o = t[s], o["s-sr"] && (!n || o["s-hn"] === n) && (void 0 === e || ot(o) === e) && (l.push(o), void 0 !== e)) return l;
		l = [...l, ...X(xt(o, "childNodes"), n, e)];
	}
	return l;
}
var tt = (t, n, e = !0) => {
	const o = [];
	(e && t["s-sr"] || !t["s-sr"]) && o.push(t);
	let s = t;
	for (; s = s.nextSibling;) ot(s) !== n || !e && s["s-sr"] || o.push(s);
	return o;
};
var nt = (t, n) => 1 === t.nodeType ? null === t.getAttribute("slot") && "" === n || t.getAttribute("slot") === n : t["s-sn"] === n || "" === n;
var et = (t, n, e, o) => {
	if (t["s-ol"] && t["s-ol"].isConnected) return;
	const s = document.createTextNode("");
	if (s["s-nr"] = t, !n["s-cr"] || !n["s-cr"].parentNode) return;
	const l = n["s-cr"].parentNode, i = xt(l, e ? "prepend" : "appendChild");
	if (void 0 !== o) {
		s["s-oo"] = o;
		const t = xt(l, "childNodes"), n = [s];
		t.forEach(((t) => {
			t["s-nr"] && n.push(t);
		})), n.sort(((t, n) => !t["s-oo"] || t["s-oo"] < (n["s-oo"] || 0) ? -1 : !n["s-oo"] || n["s-oo"] < t["s-oo"] ? 1 : 0)), n.forEach(((t) => i.call(l, t)));
	} else i.call(l, s);
	t["s-ol"] = s, t["s-sh"] = n["s-hn"];
};
var ot = (t) => "string" == typeof t["s-sn"] ? t["s-sn"] : 1 === t.nodeType && t.getAttribute("slot") || void 0;
function st(t) {
	if (t.assignedElements || t.assignedNodes || !t["s-sr"]) return;
	const n = (n) => function(t) {
		const e = [], o = this["s-sn"];
		null != t && t.flatten && console.error("\n          Flattening is not supported for Stencil non-shadow slots.\n          You can use `.childNodes` to nested slot fallback content.\n          If you have a particular use case, please open an issue on the Stencil repo.\n        ");
		const s = this["s-cr"].parentElement;
		return (s.__childNodes ? s.childNodes : Q(s.childNodes)).forEach(((t) => {
			o === ot(t) && e.push(t);
		})), n ? e.filter(((t) => 1 === t.nodeType)) : e;
	}.bind(t);
	t.assignedElements = n(!0), t.assignedNodes = n(!1);
}
function lt(t) {
	t.dispatchEvent(new CustomEvent("slotchange", {
		bubbles: !1,
		cancelable: !1,
		composed: !1
	}));
}
function it(t, n) {
	var e;
	if (!(n = n || (null == (e = t["s-ol"]) ? void 0 : e.parentElement))) return {
		slotNode: null,
		slotName: ""
	};
	const o = t["s-sn"] = ot(t) || "";
	return {
		slotNode: X(xt(n, "childNodes"), n.tagName, o)[0],
		slotName: o
	};
}
var rt = (t) => {
	if (t.__cloneNode) return;
	const n = t.__cloneNode = t.cloneNode;
	t.cloneNode = function(t) {
		const e = this.shadowRoot && true, o = n.call(this, !!e && t);
		if (!e && t) {
			let t, n, e = 0;
			const s = [
				"s-id",
				"s-cr",
				"s-lr",
				"s-rc",
				"s-sc",
				"s-p",
				"s-cn",
				"s-sr",
				"s-sn",
				"s-hn",
				"s-ol",
				"s-nr",
				"s-si",
				"s-rf",
				"s-scs"
			], l = this.__childNodes || this.childNodes;
			for (; e < l.length; e++) t = l[e]["s-nr"], n = s.every(((t) => !l[e][t])), t && (o.__appendChild ? o.__appendChild(t.cloneNode(!0)) : o.appendChild(t.cloneNode(!0))), n && o.appendChild(l[e].cloneNode(!0));
		}
		return o;
	};
};
var ct = (t) => {
	t.__appendChild || (t.__appendChild = t.appendChild, t.appendChild = function(t) {
		const { slotName: n, slotNode: e } = it(t, this);
		if (e) {
			et(t, e);
			const o = tt(e, n), s = o[o.length - 1], i = xt(xt(s, "parentNode"), "insertBefore")(t, s.nextSibling);
			return lt(e), K(this), i;
		}
		return this.__appendChild(t);
	});
};
var ut = (t) => {
	t.__removeChild || (t.__removeChild = t.removeChild, t.removeChild = function(t) {
		return t && void 0 !== t["s-sn"] && X(this.__childNodes || this.childNodes, this.tagName, t["s-sn"]) && t.isConnected ? (t.remove(), void K(this)) : this.__removeChild(t);
	});
};
var ft = (t) => {
	t.__prepend || (t.__prepend = t.prepend, t.prepend = function(...n) {
		n.forEach(((n) => {
			"string" == typeof n && (n = this.ownerDocument.createTextNode(n));
			const e = (n["s-sn"] = ot(n)) || "", o = X(xt(this, "childNodes"), this.tagName, e)[0];
			if (o) {
				et(n, o, !0);
				const t = tt(o, e)[0], l = xt(xt(t, "parentNode"), "insertBefore")(n, xt(t, "nextSibling"));
				return lt(o), l;
			}
			return 1 === n.nodeType && n.getAttribute("slot") && (n.hidden = !0), t.__prepend(n);
		}));
	});
};
var at = (t) => {
	t.__append || (t.__append = t.append, t.append = function(...t) {
		t.forEach(((t) => {
			"string" == typeof t && (t = this.ownerDocument.createTextNode(t)), this.appendChild(t);
		}));
	});
};
var dt = (t) => {
	if (t.__insertAdjacentHTML) return;
	const n = t.insertAdjacentHTML;
	t.insertAdjacentHTML = function(t, e) {
		if ("afterbegin" !== t && "beforeend" !== t) return n.call(this, t, e);
		const o = this.ownerDocument.createElement("_");
		let s;
		if (o.innerHTML = e, "afterbegin" === t) for (; s = o.firstChild;) this.prepend(s);
		else if ("beforeend" === t) for (; s = o.firstChild;) this.append(s);
	};
};
var ht = (t) => {
	t.insertAdjacentText = function(t, n) {
		this.insertAdjacentHTML(t, n);
	};
};
var vt = (t) => {
	t.__insertBefore || t.__insertBefore || (t.__insertBefore = t.insertBefore, t.insertBefore = function(t, n) {
		const { slotName: e, slotNode: o } = it(t, this), s = this.__childNodes ? this.childNodes : Q(this.childNodes);
		if (o) {
			let l = !1;
			if (s.forEach(((s) => {
				if (s !== n && null !== n);
				else {
					if (l = !0, null === n || e !== n["s-sn"]) return void this.appendChild(t);
					if (e === n["s-sn"]) {
						et(t, o);
						xt(xt(n, "parentNode"), "insertBefore")(t, n), lt(o);
					}
				}
			})), l) return t;
		}
		const l = null == n ? void 0 : n.__parentNode;
		return l && !this.isSameNode(l) ? this.appendChild(t) : this.__insertBefore(t, n);
	});
};
var pt = (t) => {
	if (t.__insertAdjacentElement) return;
	const n = t.insertAdjacentElement;
	t.insertAdjacentElement = function(t, e) {
		return "afterbegin" !== t && "beforeend" !== t ? n.call(this, t, e) : "afterbegin" === t ? (this.prepend(e), e) : "beforeend" === t ? (this.append(e), e) : e;
	};
};
var $t = (t) => {
	St("textContent", t), Object.defineProperty(t, "textContent", {
		get: function() {
			let t = "";
			return (this.__childNodes ? this.childNodes : Q(this.childNodes)).forEach(((n) => t += n.textContent || "")), t;
		},
		set: function(t) {
			(this.__childNodes ? this.childNodes : Q(this.childNodes)).forEach(((t) => {
				t["s-ol"] && t["s-ol"].remove(), t.remove();
			})), this.insertAdjacentHTML("beforeend", t);
		}
	});
};
var bt = (t) => {
	class n extends Array {
		item(t) {
			return this[t];
		}
	}
	St("children", t), Object.defineProperty(t, "children", { get() {
		return this.childNodes.filter(((t) => 1 === t.nodeType));
	} }), Object.defineProperty(t, "childElementCount", { get() {
		return this.children.length;
	} }), St("firstChild", t), Object.defineProperty(t, "firstChild", { get() {
		return this.childNodes[0] || null;
	} }), St("lastChild", t), Object.defineProperty(t, "lastChild", { get() {
		return this.childNodes[this.childNodes.length - 1] || null;
	} }), St("childNodes", t), Object.defineProperty(t, "childNodes", { get() {
		const t = new n();
		return t.push(...Q(this.__childNodes)), t;
	} });
};
var gt = (t) => {
	t && !t.__nextSibling && (St("nextSibling", t), Object.defineProperty(t, "nextSibling", { get: function() {
		var t;
		const n = null == (t = this["s-ol"]) ? void 0 : t.parentNode.childNodes, e = null == n ? void 0 : n.indexOf(this);
		return n && e > -1 ? n[e + 1] || null : this.__nextSibling;
	} }));
};
var mt = (t) => {
	t && !t.__nextElementSibling && (St("nextElementSibling", t), Object.defineProperty(t, "nextElementSibling", { get: function() {
		var t;
		const n = null == (t = this["s-ol"]) ? void 0 : t.parentNode.children, e = null == n ? void 0 : n.indexOf(this);
		return n && e > -1 ? n[e + 1] || null : this.__nextElementSibling;
	} }));
};
var yt = (t) => {
	t && !t.__previousSibling && (St("previousSibling", t), Object.defineProperty(t, "previousSibling", { get: function() {
		var t;
		const n = null == (t = this["s-ol"]) ? void 0 : t.parentNode.childNodes, e = null == n ? void 0 : n.indexOf(this);
		return n && e > -1 ? n[e - 1] || null : this.__previousSibling;
	} }));
};
var wt = (t) => {
	t && !t.__previousElementSibling && (St("previousElementSibling", t), Object.defineProperty(t, "previousElementSibling", { get: function() {
		var t;
		const n = null == (t = this["s-ol"]) ? void 0 : t.parentNode.children, e = null == n ? void 0 : n.indexOf(this);
		return n && e > -1 ? n[e - 1] || null : this.__previousElementSibling;
	} }));
};
var jt = (t) => {
	t && !t.__parentNode && (St("parentNode", t), Object.defineProperty(t, "parentNode", {
		get: function() {
			var t;
			return (null == (t = this["s-ol"]) ? void 0 : t.parentNode) || this.__parentNode;
		},
		set: function(t) {
			this.__parentNode = t;
		}
	}));
};
var Ot = [
	"children",
	"nextElementSibling",
	"previousElementSibling"
];
var Nt = [
	"childNodes",
	"firstChild",
	"lastChild",
	"nextSibling",
	"previousSibling",
	"textContent",
	"parentNode"
];
function St(t, n) {
	if (!globalThis.Node || !globalThis.Element) return;
	let e;
	Ot.includes(t) ? e = Object.getOwnPropertyDescriptor(Element.prototype, t) : Nt.includes(t) && (e = Object.getOwnPropertyDescriptor(Node.prototype, t)), e || (e = Object.getOwnPropertyDescriptor(n, t)), e && Object.defineProperty(n, "__" + t, e);
}
function xt(t, n) {
	if ("__" + n in t) {
		const e = t["__" + n];
		return "function" != typeof e ? e : e.bind(t);
	}
	return "function" != typeof t[n] ? t[n] : t[n].bind(t);
}
var Et = /* @__PURE__ */ new WeakMap();
var kt = (t, n, e) => {
	let o = x.get(t);
	_ && e ? (o = o || new CSSStyleSheet(), "string" == typeof o ? o = n : o.replaceSync(n)) : o = n, x.set(t, o);
};
var Ct = (t, n, e) => {
	var o, s, l;
	const i = Mt(n, e), r = x.get(i);
	if (!R.document) return i;
	if (t = 11 === t.nodeType ? t : R.document, r) if ("string" == typeof r) {
		let e, l = Et.get(t = t.head || t);
		l || Et.set(t, l = /* @__PURE__ */ new Set());
		const c = t.querySelector(`[${C}="${i}"]`);
		if (c) c.textContent = r;
		else if (!l.has(i)) {
			e = R.document.createElement("style"), e.textContent = r;
			const c = null != (o = L.h) ? o : function() {
				var t, n, e;
				return null != (e = null == (n = null == (t = R.document.head) ? void 0 : t.querySelector("meta[name=\"csp-nonce\"]")) ? void 0 : n.getAttribute("content")) ? e : void 0;
			}();
			if (null != c && e.setAttribute("nonce", c), !(1 & n.i)) if ("HEAD" === t.nodeName) {
				const n = t.querySelectorAll("link[rel=preconnect]"), o = n.length > 0 ? n[n.length - 1].nextSibling : t.querySelector("style");
				t.insertBefore(e, (null == o ? void 0 : o.parentNode) === t ? o : null);
			} else if ("host" in t) if (_) {
				const n = new (null != (s = t.defaultView) ? s : t.ownerDocument.defaultView).CSSStyleSheet();
				n.replaceSync(r), T ? t.adoptedStyleSheets.unshift(n) : t.adoptedStyleSheets = [n, ...t.adoptedStyleSheets];
			} else {
				const n = t.querySelector("style");
				n ? n.textContent = r + n.textContent : t.prepend(e);
			}
			else t.append(e);
			1 & n.i && t.insertBefore(e, null), 4 & n.i && (e.textContent += "slot-fb{display:contents}slot-fb[hidden]{display:none}"), l && l.add(i);
		}
	} else {
		let n = Et.get(t);
		if (n || Et.set(t, n = /* @__PURE__ */ new Set()), !n.has(i)) {
			const e = null != (l = t.defaultView) ? l : t.ownerDocument.defaultView;
			let o;
			if (r.constructor === e.CSSStyleSheet) o = r;
			else {
				o = new e.CSSStyleSheet();
				for (let t = 0; t < r.cssRules.length; t++) o.insertRule(r.cssRules[t].cssText, t);
			}
			if (T ? t.adoptedStyleSheets.push(o) : t.adoptedStyleSheets = [...t.adoptedStyleSheets, o], n.add(i), "host" in t) {
				const n = t.querySelector(`[${C}="${i}"]`);
				n && J((() => n.remove()));
			}
		}
	}
	return i;
};
var Mt = (t, n) => "sc-" + (n && 32 & t.i ? t.v + "-" + n : t.v);
var It = (t) => "object" == (t = typeof t) || "function" === t;
var Rt = (t, n, ...e) => {
	let o = null, s = null, l = null, i = !1, r = !1;
	const c = [], u = (n) => {
		for (let e = 0; e < n.length; e++) if (o = n[e], Array.isArray(o)) u(o);
		else if (null != o && "boolean" != typeof o) {
			if (i = "function" != typeof t && !It(o)) o = String(o);
			else if ("function" != typeof t && void 0 === o.i) {
				S("Invalid vNode child");
				continue;
			}
			i && r ? c[c.length - 1].p += o : c.push(i ? At(null, o) : o), r = i;
		}
	};
	if (u(e), n) {
		n.key && (s = n.key), n.name && (l = n.name);
		{
			const t = n.className || n.class;
			t && (n.class = "object" != typeof t ? t : Object.keys(t).filter(((n) => t[n])).join(" "));
		}
	}
	if ("function" == typeof t) return t(null === n ? {} : n, c, Bt);
	const f = At(t, null);
	return f.$ = n, c.length > 0 && (f.j = c), f.O = s, f.N = l, f;
};
var At = (t, n) => ({
	i: 0,
	S: t,
	p: null != n ? n : null,
	k: null,
	j: null,
	$: null,
	O: null,
	N: null
});
var Lt = {};
var Bt = {
	forEach: (t, n) => t.map(_t).forEach(n),
	map: (t, n) => t.map(_t).map(n).map(Tt)
};
var _t = (t) => ({
	vattrs: t.$,
	vchildren: t.j,
	vkey: t.O,
	vname: t.N,
	vtag: t.S,
	vtext: t.p
});
var Tt = (t) => {
	if ("function" == typeof t.vtag) {
		const n = { ...t.vattrs };
		return t.vkey && (n.key = t.vkey), t.vname && (n.name = t.vname), Rt(t.vtag, n, ...t.vchildren || []);
	}
	const n = At(t.vtag, t.vtext);
	return n.$ = t.vattrs, n.j = t.vchildren, n.O = t.vkey, n.N = t.vname, n;
};
var Ft = (t, n, e, o, s, l, i, r = []) => {
	let c, u, f, a;
	const d = s["s-sc"];
	if (1 === l.nodeType) {
		if (c = l.getAttribute(M), c && (u = c.split("."), u[0] === i || "0" === u[0])) {
			f = Dt({
				i: 0,
				C: u[0],
				M: u[1],
				I: u[2],
				R: u[3],
				S: l.tagName.toLowerCase(),
				k: l,
				$: { class: l.className || "" }
			}), n.push(f), l.removeAttribute(M), t.j || (t.j = []), d && u[0] === i && (l["s-si"] = d, f.$.class += " " + d);
			const s = f.k.getAttribute("s-sn");
			"string" == typeof s && ("slot-fb" === f.S && (Wt(s, u[2], f, l, t, n, e, o, r), d && l.classList.add(d)), f.k["s-sn"] = s, f.k.removeAttribute("s-sn")), void 0 !== f.R && (t.j[f.R] = f), t = f, o && "0" === f.I && (o[f.R] = f.k);
		}
		if (l.shadowRoot) for (a = l.shadowRoot.childNodes.length - 1; a >= 0; a--) Ft(t, n, e, o, s, l.shadowRoot.childNodes[a], i, r);
		const h = l.__childNodes || l.childNodes;
		for (a = h.length - 1; a >= 0; a--) Ft(t, n, e, o, s, h[a], i, r);
	} else if (8 === l.nodeType) u = l.nodeValue.split("."), (u[1] === i || "0" === u[1]) && (c = u[0], f = Dt({
		C: u[1],
		M: u[2],
		I: u[3],
		R: u[4] || "0",
		k: l,
		$: null,
		j: null,
		O: null,
		N: null,
		S: null,
		p: null
	}), "t" === c ? (f.k = Ht(l, 3), f.k && 3 === f.k.nodeType && (f.p = f.k.textContent, n.push(f), l.remove(), i === f.C && (t.j || (t.j = []), t.j[f.R] = f), o && "0" === f.I && (o[f.R] = f.k))) : "c" === c ? (f.k = Ht(l, 8), f.k && 8 === f.k.nodeType && (n.push(f), l.remove())) : f.C === i && ("s" === c ? Wt(l["s-sn"] = u[5] || "", u[2], f, l, t, n, e, o, r) : "r" === c && (o ? l.remove() : (s["s-cr"] = l, l["s-cn"] = !0))));
	else if (t && "style" === t.S) {
		const n = At(null, l.textContent);
		n.k = l, n.R = "0", t.j = [n];
	}
	return t;
};
var Ut = (t, n) => {
	if (1 === t.nodeType) {
		const e = t[k] || t.getAttribute(k);
		e && n.set(e, t);
		let o = 0;
		if (t.shadowRoot) for (; o < t.shadowRoot.childNodes.length; o++) Ut(t.shadowRoot.childNodes[o], n);
		const s = t.__childNodes || t.childNodes;
		for (o = 0; o < s.length; o++) Ut(s[o], n);
	} else if (8 === t.nodeType) {
		const e = t.nodeValue.split(".");
		"o" === e[0] && (n.set(e[1] + "." + e[2], t), t.nodeValue = "", t["s-en"] = e[3]);
	}
};
var Dt = (t) => ({
	i: 0,
	C: null,
	M: null,
	I: null,
	R: "0",
	k: null,
	$: null,
	j: null,
	O: null,
	N: null,
	S: null,
	p: null,
	...t
});
function Wt(t, n, e, o, s, l, i, r, c) {
	o["s-sr"] = !0, e.N = t || null, e.S = "slot";
	const u = (null == s ? void 0 : s.k) ? s.k["s-id"] || s.k.getAttribute("s-id") : "";
	if (r && R.document) {
		const l = e.k = R.document.createElement(e.S);
		e.N && e.k.setAttribute("name", t), s.k.shadowRoot && u && u !== e.C ? xt(s.k, "insertBefore")(l, xt(s.k, "children")[0]) : xt(xt(o, "parentNode"), "insertBefore")(l, o), Vt(c, n, t, o, e.C), o.remove(), "0" === e.I && (r[e.R] = e.k);
	} else {
		const l = e.k, i = u && u !== e.C && s.k.shadowRoot;
		Vt(c, n, t, o, i ? u : e.C), st(o), i && s.k.insertBefore(l, s.k.children[0]);
	}
	l.push(e), i.push(e), s.j || (s.j = []), s.j[e.R] = e;
}
var Vt = (t, n, e, o, s) => {
	var l, i;
	let r = o.nextSibling;
	if (t[n] = t[n] || [], r && !(null == (l = r.nodeValue) ? void 0 : l.startsWith("s."))) do
		!r || (r.getAttribute && r.getAttribute("slot") || r["s-sn"]) !== e && ("" !== e || r["s-sn"] || r.getAttribute && r.getAttribute("slot") || 8 !== r.nodeType && 3 !== r.nodeType) || (r["s-sn"] = e, t[n].push({
			slot: o,
			node: r,
			hostId: s
		})), r = null == r ? void 0 : r.nextSibling;
	while (r && !(null == (i = r.nodeValue) ? void 0 : i.startsWith("s.")));
};
var Ht = (t, n) => {
	let e = t;
	do
		e = e.nextSibling;
	while (e && (e.nodeType !== n || !e.nodeValue));
	return e;
};
var Pt = (t) => E.push(t);
var qt = (t) => {
	var n;
	return null == (n = O(t)) ? void 0 : n.A;
};
var zt = (t) => {
	if (!t) return;
	const n = Object.keys(t);
	if (0 === n.length) return;
	let e = !1;
	for (const o of n) {
		if (e) break;
		for (const n of t[o]) if ("string" == typeof n) {
			e = !0;
			break;
		}
	}
	if (!e) return t;
	const o = {};
	for (const e of n) o[e] = t[e].map(((t) => "string" == typeof t ? { [t]: 0 } : t));
	return o;
};
var Jt = class t {
	static fromLocalValue(n) {
		const e = n[b], o = g in n ? n[g] : void 0;
		switch (e) {
			case "string":
			case "boolean": return o;
			case "bigint": return BigInt(o);
			case "undefined": return;
			case "null": return null;
			case "number": return "NaN" === o ? NaN : "-0" === o ? -0 : "Infinity" === o ? Infinity : "-Infinity" === o ? -Infinity : o;
			case "array": return o.map(((n) => t.fromLocalValue(n)));
			case "date": return new Date(o);
			case "map":
				const n = /* @__PURE__ */ new Map();
				for (const [e, s] of o) {
					const o = "object" == typeof e && null !== e ? t.fromLocalValue(e) : e, l = t.fromLocalValue(s);
					n.set(o, l);
				}
				return n;
			case "object":
				const s = {};
				for (const [n, e] of o) s[n] = t.fromLocalValue(e);
				return s;
			case "regexp":
				const { pattern: l, flags: i } = o;
				return new RegExp(l, i);
			case "set":
				const r = /* @__PURE__ */ new Set();
				for (const n of o) r.add(t.fromLocalValue(n));
				return r;
			case "symbol": return Symbol(o);
			default: throw new Error(`Unsupported type: ${e}`);
		}
	}
	static fromLocalValueArray(n) {
		return n.map(((n) => t.fromLocalValue(n)));
	}
	static isLocalValueObject(t) {
		if ("object" != typeof t || null === t) return !1;
		if (!t.hasOwnProperty(b)) return !1;
		const n = t[b];
		return !!Object.values({
			...p,
			...$
		}).includes(n) && ("null" === n || "undefined" === n || t.hasOwnProperty(g));
	}
};
var Yt;
var Gt;
var Zt;
var Kt = (t, n) => {
	return "string" == typeof t && t.startsWith(m) ? t = "string" == typeof (e = t) && e.startsWith(m) ? Jt.fromLocalValue(JSON.parse(function(t) {
		const n = atob(t), e = new Uint8Array(n.length);
		for (let t = 0; t < n.length; t++) e[t] = n.charCodeAt(t);
		return new TextDecoder().decode(e);
	}(e.slice(11)))) : e : null == t || It(t) ? t : 4 & n ? "false" !== t && ("" === t || !!t) : 2 & n ? "string" == typeof t ? parseFloat(t) : "number" == typeof t ? t : NaN : 1 & n ? String(t) : t;
	var e;
};
var Qt = (t, n, e) => {
	const o = t;
	return { emit: (t) => Xt(o, n, {
		bubbles: !!(4 & e),
		composed: !!(2 & e),
		cancelable: !!(1 & e),
		detail: t
	}) };
};
var Xt = (t, n, e) => {
	const o = L.ce(n, e);
	return t.dispatchEvent(o), o;
};
var tn = (t, n, e, o, s, l, i) => {
	if (e === o) return;
	let r = N(t, n), c = n.toLowerCase();
	if ("class" === n) {
		const n = t.classList, s = sn(e);
		let l = sn(o);
		if ((t["s-si"] || t["s-sc"]) && i) {
			const e = t["s-sc"] || t["s-si"];
			l.push(e), s.forEach(((t) => {
				t.startsWith(e) && l.push(t);
			})), l = [...new Set(l)].filter(((t) => t)), n.add(...l);
		} else n.remove(...s.filter(((t) => t && !l.includes(t)))), n.add(...l.filter(((t) => t && !s.includes(t))));
	} else if ("style" === n) {
		for (const n in e) o && null != o[n] || (n.includes("-") ? t.style.removeProperty(n) : t.style[n] = "");
		for (const n in o) e && o[n] === e[n] || (n.includes("-") ? t.style.setProperty(n, o[n]) : t.style[n] = o[n]);
	} else if ("key" === n);
	else if ("ref" === n) o && En(o, t);
	else if (t.__lookupSetter__(n) || "o" !== n[0] || "n" !== n[1]) {
		if ("a" === n[0] && n.startsWith("attr:")) {
			const e = n.slice(5);
			let s;
			{
				const n = O(t);
				if (n && n.o && n.o.t) {
					const t = n.o.t[e];
					t && t[1] && (s = t[1]);
				}
			}
			s || (s = e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase()), null == o || !1 === o ? !1 === o && "" !== t.getAttribute(s) || t.removeAttribute(s) : t.setAttribute(s, !0 === o ? "" : o);
			return;
		}
		if ("p" === n[0] && n.startsWith("prop:")) {
			const e = n.slice(5);
			try {
				t[e] = o;
			} catch (t) {}
			return;
		}
		{
			const i = It(o);
			if ((r || i && null !== o) && !s) try {
				if (t.tagName.includes("-")) t[n] !== o && (t[n] = o);
				else {
					const s = null == o ? "" : o;
					"list" === n ? r = !1 : null != e && t[n] === s || ("function" == typeof t.__lookupSetter__(n) ? t[n] = s : t.setAttribute(n, s));
				}
			} catch (t) {}
			let u = !1;
			c !== (c = c.replace(/^xlink\:?/, "")) && (n = c, u = !0), null == o || !1 === o ? (!1 !== o || "" === t.getAttribute(n) || 4 & l && !en(n)) && (u ? t.removeAttributeNS(I, n) : t.removeAttribute(n)) : (!r || 4 & l || s) && !i && 1 === t.nodeType && (o = !0 === o ? "" : o, u ? t.setAttributeNS(I, n, o) : t.setAttribute(n, o));
		}
	} else if (n = "-" === n[2] ? n.slice(3) : N(R, c) ? c.slice(2) : c[2] + n.slice(3), e || o) {
		const s = n.endsWith(ln);
		n = n.replace(rn, ""), e && L.rel(t, n, e, s), o && L.ael(t, n, o, s);
	}
};
var nn = /* @__PURE__ */ new Set([
	"draggable",
	"contenteditable",
	"spellcheck"
]);
var en = (t) => nn.has(t) || t.startsWith("aria-");
var on = /\s/;
var sn = (t) => ("object" == typeof t && t && "baseVal" in t && (t = t.baseVal), t && "string" == typeof t ? t.split(on) : []);
var ln = "Capture";
var rn = new RegExp(ln + "$");
var cn = (t, n, e, o) => {
	const s = 11 === n.k.nodeType && n.k.host ? n.k.host : n.k, l = t && t.$ || {}, i = n.$ || {};
	for (const t of un(Object.keys(l))) t in i || tn(s, t, l[t], void 0, e, n.i, o);
	for (const t of un(Object.keys(i))) tn(s, t, l[t], i[t], e, n.i, o);
};
function un(t) {
	return t.includes("ref") ? [...t.filter(((t) => "ref" !== t)), "ref"] : t;
}
var fn = !1;
var an = !1;
var dn = !1;
var hn = !1;
var vn = [];
var pn = [];
var $n = (t, n, e) => {
	var o;
	const s = n.j[e];
	let l, i, r, c = 0;
	if (fn || (dn = !0, "slot" === s.S && (s.i |= s.j ? 2 : 1)), null != s.p) l = s.k = R.document.createTextNode(s.p);
	else if (1 & s.i) l = s.k = R.document.createTextNode(""), cn(null, s, hn);
	else {
		if (hn || (hn = "svg" === s.S), !R.document) throw new Error("You are trying to render a Stencil component in an environment that doesn't support the DOM.");
		if (l = s.k = R.document.createElementNS(hn ? "http://www.w3.org/2000/svg" : "http://www.w3.org/1999/xhtml", !fn && 2 & s.i ? "slot-fb" : s.S), hn && "foreignObject" === s.S && (hn = !1), cn(null, s, hn), null != (u = Yt) && void 0 !== u && l["s-si"] !== Yt && l.classList.add(l["s-si"] = Yt), s.j) {
			const n = "template" === s.S ? l.content : l;
			for (c = 0; c < s.j.length; ++c) i = $n(t, s, c), i && n.appendChild(i);
		}
		"svg" === s.S ? hn = !1 : "foreignObject" === l.tagName && (hn = !0);
	}
	var u;
	return l["s-hn"] = Zt, 3 & s.i && (l["s-sr"] = !0, l["s-cr"] = Gt, l["s-sn"] = s.N || "", l["s-rf"] = null == (o = s.$) ? void 0 : o.ref, st(l), r = t && t.j && t.j[e], r && r.S === s.S && t.k && bn(t.k), Cn(Gt, l, n.k, null == t ? void 0 : t.k)), l;
};
var bn = (t) => {
	L.i |= 1;
	const n = t.closest(Zt.toLowerCase());
	if (null != n) {
		const e = Array.from(n.__childNodes || n.childNodes).find(((t) => t["s-cr"])), o = Array.from(t.__childNodes || t.childNodes);
		for (const t of e ? o.reverse() : o) null != t["s-sh"] && (kn(n, t, null != e ? e : null), t["s-sh"] = void 0, dn = !0);
	}
	L.i &= -2;
};
var gn = (t, n) => {
	L.i |= 1;
	const e = Array.from(t.__childNodes || t.childNodes);
	if (t["s-sr"]) {
		let n = t;
		for (; n = n.nextSibling;) n && n["s-sn"] === t["s-sn"] && n["s-sh"] === Zt && e.push(n);
	}
	for (let t = e.length - 1; t >= 0; t--) {
		const o = e[t];
		o["s-hn"] !== Zt && o["s-ol"] && (kn(jn(o).parentNode, o, jn(o)), o["s-ol"].remove(), o["s-ol"] = void 0, o["s-sh"] = void 0, dn = !0), n && gn(o, n);
	}
	L.i &= -2;
};
var mn = (t, n, e, o, s, l) => {
	let i, r = t["s-cr"] && t["s-cr"].parentNode || t;
	for (r.shadowRoot && r.tagName === Zt && (r = r.shadowRoot), "template" === e.S && (r = r.content); s <= l; ++s) o[s] && (i = $n(null, e, s), i && (o[s].k = i, kn(r, i, jn(n))));
};
var yn = (t, n, e) => {
	for (let o = n; o <= e; ++o) {
		const n = t[o];
		if (n) {
			const t = n.k;
			xn(n), t && (an = !0, t["s-ol"] ? t["s-ol"].remove() : gn(t, !0), t.remove());
		}
	}
};
var wn = (t, n, e = !1) => t.S === n.S && ("slot" === t.S ? t.N === n.N : e ? (e && !t.O && n.O && (t.O = n.O), !0) : t.O === n.O);
var jn = (t) => t && t["s-ol"] || t;
var On = (t, n, e = !1) => {
	const o = n.k = t.k, s = t.j, l = n.j, i = n.S, r = n.p;
	let c;
	null == r ? (hn = "svg" === i || "foreignObject" !== i && hn, "slot" !== i || fn || t.N !== n.N && (n.k["s-sn"] = n.N || "", bn(n.k.parentElement)), cn(t, n, hn, e), null !== s && null !== l ? ((t, n, e, o, s = !1) => {
		let l, i, r = 0, c = 0, u = 0, f = 0, a = n.length - 1, d = n[0], h = n[a], v = o.length - 1, p = o[0], $ = o[v];
		const b = "template" === e.S ? t.content : t;
		for (; r <= a && c <= v;) if (null == d) d = n[++r];
		else if (null == h) h = n[--a];
		else if (null == p) p = o[++c];
		else if (null == $) $ = o[--v];
		else if (wn(d, p, s)) On(d, p, s), d = n[++r], p = o[++c];
		else if (wn(h, $, s)) On(h, $, s), h = n[--a], $ = o[--v];
		else if (wn(d, $, s)) "slot" !== d.S && "slot" !== $.S || gn(d.k.parentNode, !1), On(d, $, s), kn(b, d.k, h.k.nextSibling), d = n[++r], $ = o[--v];
		else if (wn(h, p, s)) "slot" !== d.S && "slot" !== $.S || gn(h.k.parentNode, !1), On(h, p, s), kn(b, h.k, d.k), h = n[--a], p = o[++c];
		else {
			for (u = -1, f = r; f <= a; ++f) if (n[f] && null !== n[f].O && n[f].O === p.O) {
				u = f;
				break;
			}
			u >= 0 ? (i = n[u], i.S !== p.S ? l = $n(n && n[c], e, u) : (On(i, p, s), n[u] = void 0, l = i.k), p = o[++c]) : (l = $n(n && n[c], e, c), p = o[++c]), l && kn(jn(d.k).parentNode, l, jn(d.k));
		}
		r > a ? mn(t, null == o[v + 1] ? null : o[v + 1].k, e, o, c, v) : c > v && yn(n, r, a);
	})(o, s, n, l, e) : null !== l ? (null !== t.p && (o.textContent = ""), mn(o, null, n, l, 0, l.length - 1)) : e || null === s ? e && null !== s && null === l && (n.j = s) : yn(s, 0, s.length - 1), hn && "svg" === i && (hn = !1)) : (c = o["s-cr"]) ? c.parentNode.textContent = r : t.p !== r && (o.data = r);
};
var Nn = [];
var Sn = (t) => {
	let n, e, o;
	const s = t.__childNodes || t.childNodes;
	for (const t of s) {
		if (t["s-sr"] && (n = t["s-cr"]) && n.parentNode) {
			e = n.parentNode.__childNodes || n.parentNode.childNodes;
			const s = t["s-sn"];
			for (o = e.length - 1; o >= 0; o--) if (n = e[o], !n["s-cn"] && !n["s-nr"] && n["s-hn"] !== t["s-hn"] && (!n["s-sh"] || n["s-sh"] !== t["s-hn"] || "" !== s && ot(n) === s)) if (nt(n, s)) {
				let e = Nn.find(((t) => t.L === n));
				an = !0, n["s-sn"] = n["s-sn"] || s, e ? (e.L["s-sh"] = t["s-hn"], e.B = t) : (n["s-sh"] = t["s-hn"], Nn.push({
					B: t,
					L: n
				})), n["s-sr"] && Nn.map(((t) => {
					nt(t.L, n["s-sn"]) && (e = Nn.find(((t) => t.L === n)), e && !t.B && (t.B = e.B));
				}));
			} else Nn.some(((t) => t.L === n)) || Nn.push({ L: n });
		}
		1 === t.nodeType && Sn(t);
	}
};
var xn = (t) => {
	t.$ && t.$.ref && vn.push((() => t.$.ref(null))), t.j && t.j.map(xn);
};
var En = (t, n) => {
	pn.push((() => t(n)));
};
var kn = (t, n, e, o) => {
	if ("string" == typeof n["s-sn"] && n["s-sr"] && n["s-cr"]) Cn(n["s-cr"], n, t, n.parentElement);
	else if ("string" == typeof n["s-sn"]) {
		11 !== t.getRootNode().nodeType && jt(n), t.insertBefore(n, e);
		const { slotNode: s } = it(n);
		return s && !o && lt(s), n;
	}
	return (null == t ? void 0 : t.__insertBefore) ? t.__insertBefore(n, e) : null == t ? void 0 : t.insertBefore(n, e);
};
function Cn(t, n, e, o) {
	var s, l;
	let i;
	if (t && "string" == typeof n["s-sn"] && n["s-sr"] && t.parentNode && t.parentNode["s-sc"] && (i = n["s-si"] || t.parentNode["s-sc"])) {
		const t = n["s-sn"], r = n["s-hn"];
		if (null == (s = e.classList) || s.add(i + "-s"), o && (null == (l = o.classList) ? void 0 : l.contains(i + "-s"))) {
			let n = (o.__childNodes || o.childNodes)[0], e = !1;
			for (; n;) {
				if (n["s-sn"] !== t && n["s-hn"] === r && n["s-sr"]) {
					e = !0;
					break;
				}
				n = n.nextSibling;
			}
			e || o.classList.remove(i + "-s");
		}
	}
}
var Mn = (t, n, e = !1) => {
	var o, s, l, i, r;
	const c = t.$hostElement$, u = t.o, f = t._ || At(null, null);
	var a;
	const d = (a = n) && a.S === Lt ? n : Rt(null, null, n);
	if (Zt = c.tagName, u.T && (d.$ = d.$ || {}, u.T.forEach((([t, n]) => {
		d.$[n] = c[t];
	}))), e && d.$) for (const t of Object.keys(d.$)) c.hasAttribute(t) && ![
		"key",
		"ref",
		"style",
		"class"
	].includes(t) && (d.$[t] = c[t]);
	if (d.S = null, d.i |= 4, t._ = d, d.k = f.k = c.shadowRoot || c, Yt = c["s-sc"], fn = !(!(1 & u.i) || 128 & u.i), Gt = c["s-cr"], an = !1, On(f, d, e), L.i |= 1, dn) {
		Sn(d.k);
		for (const t of Nn) {
			const n = t.L;
			if (!n["s-ol"] && R.document) {
				const t = R.document.createTextNode("");
				t["s-nr"] = n, kn(n.parentNode, n["s-ol"] = t, n, e);
			}
		}
		for (const t of Nn) {
			const n = t.L, r = t.B;
			if (1 === n.nodeType && e && (n["s-ih"] = null != (o = n.hidden) && o), r) {
				const t = r.parentNode;
				let o = r.nextSibling;
				if (o && 1 === o.nodeType) {
					let e = null == (s = n["s-ol"]) ? void 0 : s.previousSibling;
					for (; e;) {
						let s = null != (l = e["s-nr"]) ? l : null;
						if (s && s["s-sn"] === n["s-sn"] && t === (s.__parentNode || s.parentNode)) {
							for (s = s.nextSibling; s === n || (null == s ? void 0 : s["s-sr"]);) s = null == s ? void 0 : s.nextSibling;
							if (!s || !s["s-nr"]) {
								o = s;
								break;
							}
						}
						e = e.previousSibling;
					}
				}
				if ((!o && t !== (n.__parentNode || n.parentNode) || (n.__nextSibling || n.nextSibling) !== o) && n !== o) {
					if (kn(t, n, o, e), 8 === n.nodeType && n.nodeValue.startsWith("s-nt-")) {
						const t = R.document.createTextNode(n.nodeValue.replace(/^s-nt-/, ""));
						t["s-hn"] = n["s-hn"], t["s-sn"] = n["s-sn"], t["s-sh"] = n["s-sh"], t["s-sr"] = n["s-sr"], t["s-ol"] = n["s-ol"], t["s-ol"]["s-nr"] = t, kn(n.parentNode, t, n, e), n.parentNode.removeChild(n);
					}
					1 === n.nodeType && "SLOT-FB" !== n.tagName && (n.hidden = null != (i = n["s-ih"]) && i);
				}
				n && "function" == typeof r["s-rf"] && r["s-rf"](r);
			} else 1 === n.nodeType && (n.hidden = !0);
		}
	}
	if (an && K(d.k), L.i &= -2, Nn.length = 0, !fn && !(1 & u.i) && c["s-cr"]) {
		const t = d.k.__childNodes || d.k.childNodes;
		for (const n of t) if (n["s-hn"] !== Zt && !n["s-sh"]) {
			if (e && null == n["s-ih"] && (n["s-ih"] = null != (r = n.hidden) && r), 1 === n.nodeType) n.hidden = !0;
			else if (3 === n.nodeType && n.nodeValue.trim()) {
				const t = R.document.createComment("s-nt-" + n.nodeValue);
				t["s-sn"] = n["s-sn"], kn(n.parentNode, t, n, e), n.parentNode.removeChild(n);
			}
		}
	}
	Gt = void 0, vn.forEach(((t) => t())), vn.length = 0, pn.forEach(((t) => t())), pn.length = 0;
};
var In = (t, n) => {
	if (n && !t.F && n["s-p"]) {
		const e = n["s-p"].push(new Promise(((o) => t.F = () => {
			n["s-p"].splice(e - 1, 1), o();
		})));
	}
};
var Rn = (t, n) => {
	if (t.i |= 16, 4 & t.i) return void (t.i |= 512);
	In(t, t.U);
	const e = () => An(t, n);
	if (!n) return J(e);
	queueMicrotask((() => {
		e();
	}));
};
var An = (t, n) => {
	const e = t.$hostElement$, o = e;
	if (!o) throw new Error(`Can't render component <${e.tagName.toLowerCase()} /> with invalid Stencil runtime! Make sure this imported component is compiled with a \`externalRuntime: true\` flag. For more information, please refer to https://stenciljs.com/docs/custom-elements#externalruntime`);
	let s;
	return s = Wn(o, n ? "componentWillLoad" : "componentWillUpdate", void 0, e), s = Ln(s, (() => Wn(o, "componentWillRender", void 0, e))), Ln(s, (() => _n(t, o, n)));
};
var Ln = (t, n) => Bn(t) ? t.then(n).catch(((t) => {
	console.error(t), n();
})) : n();
var Bn = (t) => t instanceof Promise || t && t.then && "function" == typeof t.then;
var _n = async (t, n, e) => {
	var o;
	const s = t.$hostElement$, l = s["s-rc"];
	e && ((t) => {
		const n = t.o, e = t.$hostElement$, o = n.i, s = Ct(e.shadowRoot ? e.shadowRoot : e.getRootNode(), n, t.A);
		10 & o && (e["s-sc"] = s, e.classList.add(s + "-h"));
	})(t);
	Tn(t, n, s, e), l && (l.map(((t) => t())), s["s-rc"] = void 0);
	{
		const n = null != (o = s["s-p"]) ? o : [], e = () => Fn(t);
		0 === n.length ? e() : (Promise.all(n).then(e).catch(e), t.i |= 4, n.length = 0);
	}
};
var Tn = (t, n, e, o) => {
	try {
		n = n.render && n.render(), t.i &= -17, t.i |= 2, Mn(t, n, o);
	} catch (n) {
		S(n, t.$hostElement$);
	}
	return null;
};
var Fn = (t) => {
	const n = t.$hostElement$, e = n, o = t.U;
	Wn(e, "componentDidRender", void 0, n), 64 & t.i ? Wn(e, "componentDidUpdate", void 0, n) : (t.i |= 64, Vn(n), Wn(e, "componentDidLoad", void 0, n), t.D(n), o || Dn()), t.F && (t.F(), t.F = void 0), 512 & t.i && q((() => Rn(t, !1))), t.i &= -517;
};
var Un = (t) => {
	var n;
	{
		const e = O(t), o = null == (n = null == e ? void 0 : e.$hostElement$) ? void 0 : n.isConnected;
		return o && 2 == (18 & e.i) && Rn(e, !1), o;
	}
};
var Dn = () => {
	var t;
	q((() => Xt(R, "appload", { detail: { namespace: "ionic" } }))), null != (t = L.W) && t.size && L.W.clear();
};
var Wn = (t, n, e, o) => {
	if (t && t[n]) try {
		return t[n](e);
	} catch (t) {
		S(t, o);
	}
};
var Vn = (t) => t.classList.add("hydrated");
var Hn = (t, n, e, o) => {
	const s = O(t);
	if (!s) return;
	const l = t, i = s.l.get(n), r = s.i, c = l;
	e = Kt(e, o.t[n][0]);
	if (e !== i && !(Number.isNaN(i) && Number.isNaN(e))) {
		if (s.l.set(n, e), o.V) {
			const t = o.V[n];
			t && t.map(((t) => {
				try {
					const [[o, l]] = Object.entries(t);
					(128 & r || 1 & l) && (c ? c[o](e, i, n) : s.H.push((() => {
						s.P[o](e, i, n);
					})));
				} catch (t) {
					S(t, l);
				}
			}));
		}
		if (2 & r) {
			if (c.componentShouldUpdate && !1 === c.componentShouldUpdate(e, i, n) && !(16 & r)) return;
			16 & r || Rn(s, !1);
		}
	}
};
var Pn = (t, n) => {
	var e, o;
	const s = t.prototype;
	{
		t.watchers && !n.V && (n.V = zt(t.watchers)), t.deserializers && !n.q && (n.q = t.deserializers), t.serializers && !n.J && (n.J = t.serializers);
		const l = Object.entries(null != (e = n.t) ? e : {});
		l.map((([t, [e]]) => {
			if (31 & e || 32 & e) {
				const { get: o, set: l } = y(s, t) || {};
				o && (n.t[t][0] |= 2048), l && (n.t[t][0] |= 4096), Object.defineProperty(s, t, {
					get() {
						return o ? o.apply(this) : (n = t, O(this).l.get(n));
						var n;
					},
					configurable: !0,
					enumerable: !0
				}), Object.defineProperty(s, t, { set(o) {
					const s = O(this);
					if (s) {
						if (l) return void 0 === (32 & e ? this[t] : s.$hostElement$[t]) && s.l.get(t) && (o = s.l.get(t)), l.apply(this, [Kt(o, e)]), void Hn(this, t, o = 32 & e ? this[t] : s.$hostElement$[t], n);
						Hn(this, t, o, n);
					}
				} });
			}
		}));
		{
			const e = /* @__PURE__ */ new Map();
			s.attributeChangedCallback = function(t, o, i) {
				L.jmp((() => {
					var r;
					const c = e.get(t), u = O(this);
					if (this.hasOwnProperty(c), s.hasOwnProperty(c) && "number" == typeof this[c] && this[c] == i) return;
					if (null == c) {
						const e = null == u ? void 0 : u.i;
						if (u && e && !(8 & e) && i !== o) {
							const s = this;
							(null == (r = n.V) ? void 0 : r[t])?.forEach(((n) => {
								const [[l, r]] = Object.entries(n);
								null != s[l] && (128 & e || 1 & r) && s[l].call(s, i, o, t);
							}));
						}
						return;
					}
					const f = l.find((([t]) => t === c)), a = f ? f[1][0] : 0, d = 4 & a;
					if (512 & a && 8 & a && !It(this[c]) && (null == (h = this[c]) || !1 === h ? null : !0 === h ? "" : String(h)) === i) return;
					var h;
					const v = d && null === i && void 0 === this[c];
					d && (i = null !== i && "false" !== i);
					const p = Object.getOwnPropertyDescriptor(s, c);
					v || i == this[c] || p.get && !p.set || (this[c] = i);
				}));
			}, t.observedAttributes = Array.from(/* @__PURE__ */ new Set([...Object.keys(null != (o = n.V) ? o : {}), ...l.filter((([t, n]) => 31 & n[0])).map((([t, o]) => {
				var s;
				const l = o[1] || t;
				return e.set(l, t), 512 & o[0] && (null == (s = n.T) || s.push([t, l])), l;
			}))]));
		}
	}
	return t;
};
var qn = async (t, n, e) => {
	let o;
	try {
		if (!(32 & n.i) && (n.i |= 32, n.i &= -1025, o = t.constructor, customElements.whenDefined(t.localName).then((() => n.i |= 128)), o && o.style)) {
			let s;
			"string" == typeof o.style ? s = o.style : "string" != typeof o.style && (n.A = ((t) => E.map(((n) => n(t))).find(((t) => !!t)))(t), n.A && (s = o.style[n.A]));
			const l = Mt(e, n.A);
			if (!x.has(l)) kt(l, s, !!(1 & e.i));
		}
		const s = n.U, l = () => Rn(n, !0);
		s && s["s-rc"] ? s["s-rc"].push(l) : l();
	} catch (e) {
		S(e, t), n.F && (n.F(), n.F = void 0), !n.D || 1024 & n.i || n.D(t);
	}
};
var zn = (t) => {
	if (!R.document) return;
	const n = t["s-cr"] = R.document.createComment("");
	n["s-cn"] = !0, kn(t, n, t.firstChild);
};
var Jn = (t, n) => {
	const e = {
		i: n[0],
		v: n[1]
	};
	try {
		e.t = n[2], e.Y = n[3], e.V = zt(t.V), e.q = t.q, e.J = t.J, e.T = [], !(1 & e.i) && 256 & e.i ? (rt(o = t.prototype), ct(o), at(o), ft(o), pt(o), dt(o), ht(o), vt(o), $t(o), bt(o), ut(o)) : rt(t.prototype), (() => {
			if (!R.document) return;
			const t = R.document.querySelectorAll(`[${C}]`);
			let n = 0;
			for (; n < t.length; n++) kt(t[n].getAttribute(C), t[n].innerHTML.replace(/\/\*!@([^\/]+)\*\/[^\{]+\{/g, "$1{"), !0);
		})();
		const s = t.prototype.connectedCallback, l = t.prototype.disconnectedCallback;
		return Object.assign(t.prototype, {
			__hasHostListenerAttached: !1,
			__registerHost() {
				((t, n) => {
					const e = {
						i: 0,
						$hostElement$: t,
						o: n,
						l: /* @__PURE__ */ new Map(),
						G: /* @__PURE__ */ new Map()
					};
					e.Z = new Promise(((t) => e.D = t)), t["s-p"] = [], t["s-rc"] = [];
					const o = e;
					t.__stencil__getHostRef = () => o, 512 & n.i && j(t, e);
				})(this, e);
			},
			connectedCallback() {
				if (!this.__hasHostListenerAttached) {
					const t = O(this);
					if (!t) return;
					Gn(this, t, e.Y), this.__hasHostListenerAttached = !0;
				}
				((t) => {
					if (!(1 & L.i)) {
						const n = O(t);
						if (!n) return;
						const e = n.o;
						if (1 & n.i) Gn(t, n, e.Y), null != n && n.P || (1024 & n.i ? setTimeout((() => qn(t, n, e)), 1e3) : null != n && n.Z && n.Z.then((() => {})));
						else {
							let o;
							if (n.i |= 1, o = t.getAttribute(k), o) {
								if (1 & e.i) {
									const n = Ct(t.shadowRoot, e, t.getAttribute("s-mode"));
									t.classList.remove(n + "-h", n + "-s");
								} else if (2 & e.i) t["s-sc"] = Mt(e, t.getAttribute("s-mode"));
								((t, n, e, o) => {
									var s, l, i, r;
									const c = t.shadowRoot, u = [], f = [], a = [], d = c ? [] : null, h = At(n, null);
									let v;
									h.k = t;
									{
										const n = o.o;
										n && 10 & n.i && t["s-sc"] ? (v = t["s-sc"], t.classList.add(v + "-h")) : t["s-sc"] && delete t["s-sc"];
									}
									!R.document || L.W && L.W.size || Ut(R.document.body, L.W = /* @__PURE__ */ new Map()), t[k] = e, t.removeAttribute(k), o._ = Ft(h, u, f, d, t, t, e, a);
									let p = 0;
									const $ = u.length;
									let b;
									for (; p < $; p++) {
										b = u[p];
										const e = b.C + "." + b.M, o = L.W.get(e), l = b.k;
										if (c) {
											if ((null == (s = b.S) ? void 0 : s.toString().includes("-")) && "slot-fb" !== b.S && !b.k.shadowRoot) {
												const t = O(b.k);
												if (t) {
													const n = Mt(t.o, b.k.getAttribute("s-mode")), e = R.document.querySelector(`style[sty-id="${n}"]`);
													e && d.unshift(e.cloneNode(!0));
												}
											}
										} else l["s-hn"] = n.toUpperCase(), "slot" === b.S && (l["s-cr"] = t["s-cr"]);
										"slot" === b.S && (b.N = b.k["s-sn"] || b.k.name || null, b.j ? (b.i |= 2, b.k.childNodes.length || b.j.forEach(((t) => {
											b.k.appendChild(t.k);
										}))) : b.i |= 1), o && o.isConnected && (o.parentElement.shadowRoot && "" === o["s-en"] && o.parentNode.insertBefore(l, o.nextSibling), o.parentNode.removeChild(o), c || (l["s-oo"] = parseInt(b.M))), o && !o["s-id"] && L.W.delete(e);
									}
									const g = [], m = a.length;
									let y, w, j, N, S = 0, x = 0;
									for (; S < m; S++) if (y = a[S], y && y.length) for (j = y.length, w = 0; w < j; w++) {
										if (N = y[w], g[N.hostId] || (g[N.hostId] = L.W.get(N.hostId)), !g[N.hostId]) continue;
										const t = g[N.hostId];
										t.shadowRoot && N.node.parentElement !== t && t.insertBefore(N.node, null == (i = null == (l = y[w - 1]) ? void 0 : l.node) ? void 0 : i.nextSibling), t.shadowRoot && c || (N.slot["s-cr"] || (N.slot["s-cr"] = t["s-cr"], N.slot["s-cr"] = !N.slot["s-cr"] && t.shadowRoot ? t : (t.__childNodes || t.childNodes)[0]), et(N.node, N.slot, !1, N.node["s-oo"] || x), null != (r = N.node.parentElement) && r.shadowRoot && N.node.getAttribute && N.node.getAttribute("slot") && N.node.removeAttribute("slot"), (E = N.node) && void 0 === E.__nextSibling && globalThis.Node && (gt(E), yt(E), jt(E), E.nodeType === Node.ELEMENT_NODE && (mt(E), wt(E)))), x = (N.node["s-oo"] || x) + 1;
									}
									var E;
									if (v && f.length && f.forEach(((t) => {
										t.k.parentElement.classList.add(v + "-s");
									})), c && !c.childNodes.length) {
										let n = 0;
										const e = d.length;
										if (e) {
											for (; n < e; n++) {
												const t = d[n];
												t && c.appendChild(t);
											}
											Array.from(t.childNodes).forEach(((t) => {
												"string" != typeof t["s-en"] && "string" != typeof t["s-sn"] && (1 === t.nodeType && t.slot && t.hidden ? t.removeAttribute("hidden") : 8 !== t.nodeType || t.nodeValue || t.parentNode.removeChild(t));
											}));
										}
									}
									o.$hostElement$ = t;
								})(t, e.v, o, n);
							}
							o || 12 & e.i && zn(t);
							{
								let e = t;
								for (; e = e.parentNode || e.host;) if (1 === e.nodeType && e.hasAttribute("s-id") && e["s-p"] || e["s-p"]) {
									In(n, n.U = e);
									break;
								}
							}
							e.t && Object.entries(e.t).map((([n, [e]]) => {
								if (31 & e && Object.prototype.hasOwnProperty.call(t, n)) {
									const e = t[n];
									delete t[n], t[n] = e;
								}
							})), qn(t, n, e);
						}
					}
				})(this), s && s.call(this);
			},
			disconnectedCallback() {
				(async (t) => {
					if (!(1 & L.i)) {
						const n = O(t);
						null != n && n.K && (n.K.map(((t) => t())), n.K = void 0);
					}
					Et.has(t) && Et.delete(t), t.shadowRoot && Et.has(t.shadowRoot) && Et.delete(t.shadowRoot);
				})(this), l && l.call(this);
			},
			__attachShadow() {
				if (this.shadowRoot) {
					if ("open" !== this.shadowRoot.mode) throw new Error(`Unable to re-use existing shadow root for ${e.v}! Mode is set to ${this.shadowRoot.mode} but Stencil only supports open shadow roots.`);
				} else Z.call(this, e);
			}
		}), Object.defineProperty(t, "is", {
			value: e.v,
			configurable: !0
		}), Pn(t, e);
	} catch (n) {
		return S(n), t;
	}
	var o;
};
var Yn = (t, n) => n;
var Gn = (t, n, e) => {
	e && R.document && e.map((([e, o, s]) => {
		const l = Kn(R.document, t, e), i = Zn(n, s), r = Qn(e);
		L.ael(l, o, i, r), (n.K = n.K || []).push((() => L.rel(l, o, i, r)));
	}));
};
var Zn = (t, n) => (e) => {
	try {
		t.$hostElement$[n](e);
	} catch (n) {
		S(n, t.$hostElement$);
	}
};
var Kn = (t, n, e) => 4 & e ? t : 8 & e ? R : 16 & e ? t.body : n;
var Qn = (t) => B ? {
	passive: !!(1 & t),
	capture: !!(2 & t)
} : !!(2 & t);
function oe(t) {
	return t;
}
//#endregion
export { oe as _, Pt as a, v as b, Un as c, a as d, d as f, o as g, n as h, Lt as i, Y as l, h as m, J as n, Qt as o, e as p, Jn as r, Rt as s, A as t, Yn as u, qt as v, z as x, s as y };
