import { n as J, x as z } from "./p-1sJ0ZDPe-Ppa1imUr.js";
import { m as t } from "./p-C09TXohi-Bhh_iTHA.js";
import { n as c, s as l } from "./p-qAXsfUff-DNL0QHRS.js";
//#region node_modules/@ionic/core/components/p-BT9-hMMz.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var n = () => {
	const n = window;
	n.addEventListener("statusTap", (() => {
		z((() => {
			const o = document.elementFromPoint(n.innerWidth / 2, n.innerHeight / 2);
			if (!o) return;
			const e = l(o);
			e && new Promise(((o) => t(e, o))).then((() => {
				J((async () => {
					e.style.setProperty("--overflow", "hidden"), await c(e, 300), e.style.removeProperty("--overflow");
				}));
			}));
		}));
	}));
};
//#endregion
export { n as startStatusTap };
