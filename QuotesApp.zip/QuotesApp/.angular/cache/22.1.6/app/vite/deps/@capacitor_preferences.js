import { registerPlugin } from "./@capacitor_core.js";
//#region node_modules/@capacitor/preferences/dist/esm/index.js
var Preferences = registerPlugin("Preferences", { web: () => import("./web-CFK_q7Re.js").then((m) => new m.PreferencesWeb()) });
//#endregion
export { Preferences };
