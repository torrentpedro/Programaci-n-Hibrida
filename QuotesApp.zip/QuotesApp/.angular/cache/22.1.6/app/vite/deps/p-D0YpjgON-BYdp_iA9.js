import { t as __exportAll } from "./jeep-sqlite.entry-CLsl_8E4.js";
//#region node_modules/@ionic/core/components/p-B_gJaBk0.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var t$1 = class {
	constructor(t, s, i, h, e) {
		this.id = s, this.name = i, this.disableScroll = e, this.priority = 1e6 * h + s, this.ctrl = t;
	}
	canStart() {
		return !!this.ctrl && this.ctrl.canStart(this.name);
	}
	start() {
		return !!this.ctrl && this.ctrl.start(this.name, this.id, this.priority);
	}
	capture() {
		if (!this.ctrl) return !1;
		const t = this.ctrl.capture(this.name, this.id, this.priority);
		return t && this.disableScroll && this.ctrl.disableScroll(this.id), t;
	}
	release() {
		this.ctrl && (this.ctrl.release(this.id), this.disableScroll && this.ctrl.enableScroll(this.id));
	}
	destroy() {
		this.release(), this.ctrl = void 0;
	}
};
var s$1 = class {
	constructor(t, s, i, h) {
		this.id = s, this.disable = i, this.disableScroll = h, this.ctrl = t;
	}
	block() {
		if (this.ctrl) {
			if (this.disable) for (const t of this.disable) this.ctrl.disableGesture(t, this.id);
			this.disableScroll && this.ctrl.disableScroll(this.id);
		}
	}
	unblock() {
		if (this.ctrl) {
			if (this.disable) for (const t of this.disable) this.ctrl.enableGesture(t, this.id);
			this.disableScroll && this.ctrl.enableScroll(this.id);
		}
	}
	destroy() {
		this.unblock(), this.ctrl = void 0;
	}
};
var i$1 = "backdrop-no-scroll";
var h = new class {
	constructor() {
		this.gestureId = 0, this.requestedStart = /* @__PURE__ */ new Map(), this.disabledGestures = /* @__PURE__ */ new Map(), this.disabledScroll = /* @__PURE__ */ new Set();
	}
	createGesture(s) {
		return new t$1(this, this.newID(), s.name, s.priority ?? 0, !!s.disableScroll);
	}
	createBlocker(t = {}) {
		return new s$1(this, this.newID(), t.disable, !!t.disableScroll);
	}
	start(t, s, i) {
		return this.canStart(t) ? (this.requestedStart.set(s, i), !0) : (this.requestedStart.delete(s), !1);
	}
	capture(t, s, i) {
		if (!this.start(t, s, i)) return !1;
		const h = this.requestedStart;
		let e = -1e4;
		if (h.forEach(((t) => {
			e = Math.max(e, t);
		})), e === i) {
			this.capturedId = s, h.clear();
			const i = new CustomEvent("ionGestureCaptured", { detail: { gestureName: t } });
			return document.dispatchEvent(i), !0;
		}
		return h.delete(s), !1;
	}
	release(t) {
		this.requestedStart.delete(t), this.capturedId === t && (this.capturedId = void 0);
	}
	disableGesture(t, s) {
		let i = this.disabledGestures.get(t);
		void 0 === i && (i = /* @__PURE__ */ new Set(), this.disabledGestures.set(t, i)), i.add(s);
	}
	enableGesture(t, s) {
		const i = this.disabledGestures.get(t);
		void 0 !== i && i.delete(s);
	}
	disableScroll(t) {
		this.disabledScroll.add(t), 1 === this.disabledScroll.size && document.body.classList.add("backdrop-no-scroll");
	}
	enableScroll(t) {
		this.disabledScroll.delete(t), 0 === this.disabledScroll.size && document.body.classList.remove("backdrop-no-scroll");
	}
	canStart(t) {
		return void 0 === this.capturedId && !this.isDisabled(t);
	}
	isCaptured() {
		return void 0 !== this.capturedId;
	}
	isScrollDisabled() {
		return this.disabledScroll.size > 0;
	}
	isDisabled(t) {
		const s = this.disabledGestures.get(t);
		return !!(s && s.size > 0);
	}
	newID() {
		return this.gestureId++, this.gestureId;
	}
}();
//#endregion
//#region node_modules/@ionic/core/components/p-D0YpjgON.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var p_D0YpjgON_exports = /* @__PURE__ */ __exportAll({
	GESTURE_CONTROLLER: () => h,
	createGesture: () => n
});
var t = (e, t, o, n) => {
	const r = {
		capture: !1,
		passive: !!n.passive
	};
	let s, i;
	return e.__zone_symbol__addEventListener ? (s = "__zone_symbol__addEventListener", i = "__zone_symbol__removeEventListener") : (s = "addEventListener", i = "removeEventListener"), e[s](t, o, r), () => {
		e[i](t, o, r);
	};
};
var o = (e) => e instanceof Document ? e : e.ownerDocument;
var n = (n) => {
	let c = !1, a = !1, d = !0, u = !1;
	const v = {
		direction: "x",
		passive: !0,
		maxAngle: 40,
		threshold: 10,
		...n
	}, l = v.canStart, m = v.onWillStart, p = v.onStart, f = v.onEnd, _ = v.notCaptured, h$1 = v.onMove, y = v.threshold, b = v.passive, D = v.blurOnStart, x = {
		type: "pan",
		startX: 0,
		startY: 0,
		startTime: 0,
		currentX: 0,
		currentY: 0,
		velocityX: 0,
		velocityY: 0,
		deltaX: 0,
		deltaY: 0,
		currentTime: 0,
		event: void 0,
		data: void 0
	}, E = ((e, t, o) => {
		const n = o * (Math.PI / 180), r = "x" === e, s = Math.cos(n), i = t * t;
		let c = 0, a = 0, d = !1, u = 0;
		return {
			start(e, t) {
				c = e, a = t, u = 0, d = !0;
			},
			detect(e, t) {
				if (!d) return !1;
				const o = e - c, n = t - a, v = o * o + n * n;
				if (v < i) return !1;
				const m = (r ? o : n) / Math.sqrt(v);
				return u = m > s ? 1 : m < -s ? -1 : 0, d = !1, !0;
			},
			isGesture: () => 0 !== u,
			getDirection: () => u
		};
	})(v.direction, v.threshold, v.maxAngle), L = h.createGesture({
		name: n.gestureName,
		priority: n.gesturePriority,
		disableScroll: n.disableScroll
	}), X = () => {
		c && (u = !1, h$1 && h$1(x));
	}, Y = () => !!L.capture() && (c = !0, d = !1, x.startX = x.currentX, x.startY = x.currentY, x.startTime = x.currentTime, m ? m(x).then(g) : g(), !0), g = () => {
		D && (() => {
			if ("undefined" != typeof document) {
				const e = document.activeElement;
				e?.blur && e.blur();
			}
		})(), p && p(x), d = !0;
	}, M = () => {
		c = !1, a = !1, u = !1, d = !0, L.release();
	}, z = (e) => {
		const t = c, o = d;
		M(), o && (r(x, e), t ? f && f(x) : _ && _(x));
	}, A = ((e, n, r, s, i) => {
		let c, a, d, u, v, l, m, p = 0;
		const f = (o) => {
			p = Date.now() + 2e3, n(o) && (!a && r && (a = t(e, "touchmove", r, i)), d || (d = t(o.target, "touchend", h, i)), u || (u = t(o.target, "touchcancel", h, i)));
		}, _ = (s) => {
			p > Date.now() || n(s) && (!l && r && (l = t(o(e), "mousemove", r, i)), m || (m = t(o(e), "mouseup", y, i)));
		}, h = (e) => {
			b(), s && s(e);
		}, y = (e) => {
			D(), s && s(e);
		}, b = () => {
			a && a(), d && d(), u && u(), a = d = u = void 0;
		}, D = () => {
			l && l(), m && m(), l = m = void 0;
		}, x = () => {
			b(), D();
		}, E = (o = !0) => {
			o ? (c || (c = t(e, "touchstart", f, i)), v || (v = t(e, "mousedown", _, i))) : (c && c(), v && v(), c = v = void 0, x());
		};
		return {
			enable: E,
			stop: x,
			destroy: () => {
				E(!1), s = r = n = void 0;
			}
		};
	})(v.el, ((e) => {
		const t = i(e);
		return !(a || !d) && (s(e, x), x.startX = x.currentX, x.startY = x.currentY, x.startTime = x.currentTime = t, x.velocityX = x.velocityY = x.deltaX = x.deltaY = 0, x.event = e, (!l || !1 !== l(x)) && (L.release(), !!L.start() && (a = !0, 0 === y ? Y() : (E.start(x.startX, x.startY), !0))));
	}), ((e) => {
		c ? !u && d && (u = !0, r(x, e), requestAnimationFrame(X)) : (r(x, e), E.detect(x.currentX, x.currentY) && (E.isGesture() && Y() || B()));
	}), z, { passive: b }), B = () => {
		M(), A.stop(), _ && _(x);
	};
	return {
		enable(e = !0) {
			e || (c && z(void 0), M()), A.enable(e);
		},
		destroy() {
			L.destroy(), A.destroy();
		}
	};
};
var r = (e, t) => {
	if (!t) return;
	const o = e.currentX, n = e.currentY, r = e.currentTime;
	s(t, e);
	const c = e.currentX, a = e.currentY, d = (e.currentTime = i(t)) - r;
	if (d > 0 && d < 100) {
		const t = (a - n) / d;
		e.velocityX = (c - o) / d * .7 + .3 * e.velocityX, e.velocityY = .7 * t + .3 * e.velocityY;
	}
	e.deltaX = c - e.startX, e.deltaY = a - e.startY, e.event = t;
};
var s = (e, t) => {
	let o = 0, n = 0;
	if (e) {
		const t = e.changedTouches;
		if (t && t.length > 0) {
			const e = t[0];
			o = e.clientX, n = e.clientY;
		} else void 0 !== e.pageX && (o = e.pageX, n = e.pageY);
	}
	t.currentX = o, t.currentY = n;
};
var i = (e) => e.timeStamp || Date.now();
//#endregion
export { i$1 as i, p_D0YpjgON_exports as n, h as r, n as t };
