import { n as o, t as d } from "./p-ZjP4CjeZ-BnW-oeAv.js";
import { h as u$1, i as d$1, m as t } from "./p-C09TXohi-Bhh_iTHA.js";
import { a as h$1, s as l$1, t as a } from "./p-qAXsfUff-DNL0QHRS.js";
import { n as t$1, t as e } from "./p-BMPN55of-Bt4HbXz4.js";
//#region node_modules/@ionic/core/components/p-C-NbvXu4.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var l = /* @__PURE__ */ new WeakMap();
var u = (o, t, n, i = 0, e = !1) => {
	l.has(o) !== n && (n ? f(o, t, i, e) : w(o, t));
};
var f = (o, t, n, i = !1) => {
	const e = t.parentNode, a = t.cloneNode(!1);
	a.classList.add("cloned-input"), a.tabIndex = -1, i && (a.disabled = !0);
	const r = "rtl" === o.ownerDocument.dir;
	a.style.insetInlineStart = r ? e.offsetWidth - t.offsetLeft - t.offsetWidth + "px" : `${t.offsetLeft}px`, e.appendChild(a), l.set(o, a);
	const s = r ? 9999 : -9999;
	o.style.pointerEvents = "none", t.style.transform = `translate3d(${s}px,${n}px,0) scale(0)`;
};
var w = (o, t) => {
	const n = l.get(o);
	n && (l.delete(o), n.remove()), o.style.pointerEvents = "", t.style.transform = "";
};
var p = "input, textarea, [no-blur], [contenteditable]";
var m = "$ionPaddingTimer";
var h = (o, t, n) => {
	const i = o[m];
	i && clearTimeout(i), t > 0 ? o.style.setProperty("--keyboard-offset", `${t}px`) : o[m] = setTimeout((() => {
		o.style.setProperty("--keyboard-offset", "0px"), n && n();
	}), 120);
};
var b = (o, t, n) => {
	o.addEventListener("focusout", (() => {
		t && h(t, 0, n);
	}), { once: !0 });
};
var y = 0;
var S = "data-ionic-skip-scroll-assist";
var D = (o) => {
	if (document.activeElement === o) return;
	const t = o.getAttribute("id"), n = o.closest(`label[for="${t}"]`), i = document.activeElement?.closest(`label[for="${t}"]`);
	null !== n && n === i || (o.setAttribute(S, "true"), o.focus());
};
var M = async (o, t, e, a$2, r, s, d = !1, c = 0, l = !0) => {
	if (!e && !a$2) return;
	const f = ((o, t, n, i) => ((o, t, n, i) => {
		const e = o.top, a = o.bottom, r = t.top, s = r + 15, d = Math.min(t.bottom, i - n) - 50 - a, c = s - e, l = Math.round(d < 0 ? -d : c > 0 ? -c : 0), u = Math.min(l, e - r);
		return {
			scrollAmount: u,
			scrollDuration: Math.min(400, Math.max(150, Math.abs(u) / .3)),
			scrollPadding: n,
			inputSafeY: 4 - (e - s)
		};
	})((o.closest("ion-item,[ion-item]") ?? o).getBoundingClientRect(), t.getBoundingClientRect(), n, i))(o, e || a$2, r, c);
	if (e && Math.abs(f.scrollAmount) < 4) return D(t), void (s && null !== e && (h(e, y), b(t, e, (() => y = 0))));
	if (u(o, t, !0, f.inputSafeY, d), D(t), s && e && (y = f.scrollPadding, h(e, y)), "undefined" != typeof window) {
		let a$1;
		const r = async () => {
			void 0 !== a$1 && clearTimeout(a$1), window.removeEventListener("ionKeyboardDidShow", d), window.removeEventListener("ionKeyboardDidShow", r), e && await h$1(e, 0, f.scrollAmount, f.scrollDuration), u(o, t, !1, f.inputSafeY), document.activeElement === t && D(t), s && b(t, e, (() => y = 0));
		}, d = () => {
			window.removeEventListener("ionKeyboardDidShow", d), window.addEventListener("ionKeyboardDidShow", r);
		};
		if (e) {
			const o = await a(e);
			if (l && f.scrollAmount > o.scrollHeight - o.clientHeight - o.scrollTop) return "password" === t.type ? (f.scrollAmount += 50, window.addEventListener("ionKeyboardDidShow", d)) : window.addEventListener("ionKeyboardDidShow", r), void (a$1 = setTimeout(r, 1e3));
		}
		r();
	}
};
var x = async (n, i) => {
	if (void 0 === o) return;
	const l = "ios" === i, f = "android" === i, w = n.getNumber("keyboardHeight", 290), m = n.getBoolean("scrollAssist", !0), h = n.getBoolean("hideCaretOnScroll", l), b = n.getBoolean("inputBlurring", !1), y = n.getBoolean("scrollPadding", !0), D = Array.from(o.querySelectorAll("ion-input, ion-textarea")), x = /* @__PURE__ */ new WeakMap(), K = /* @__PURE__ */ new WeakMap(), v = await e.getResizeMode(), k = async (t$2) => {
		await new Promise(((o) => t(t$2, o)));
		const n = t$2.shadowRoot || t$2, i = n.querySelector("input") || n.querySelector("textarea"), c = l$1(t$2), l = c ? null : t$2.closest("ion-footer");
		if (i) {
			if (c && h && !x.has(t$2)) {
				const o = ((o, t, n) => {
					if (!n || !t) return () => {};
					const i = (n) => {
						var i;
						(i = t) === i.getRootNode().activeElement && u(o, t, n);
					}, e = () => u(o, t, !1), s = () => i(!0), d = () => i(!1);
					return u$1(n, "ionScrollStart", s), u$1(n, "ionScrollEnd", d), t.addEventListener("blur", e), () => {
						d$1(n, "ionScrollStart", s), d$1(n, "ionScrollEnd", d), t.removeEventListener("blur", e);
					};
				})(t$2, i, c);
				x.set(t$2, o);
			}
			if ("date" !== i.type && "datetime-local" !== i.type && (c || l) && m && !K.has(t$2)) {
				const n = ((t, n, i, e, a, r, s, c = !1) => {
					const l = r && (void 0 === s || s.mode === t$1.None);
					let u = !1;
					const f = void 0 !== d ? d.innerHeight : 0, w = (o) => {
						!1 !== u ? M(t, n, i, e, o.detail.keyboardHeight, l, c, f, !1) : u = !0;
					}, p = () => {
						u = !1, d?.removeEventListener("ionKeyboardDidShow", w), t.removeEventListener("focusout", p);
					}, m = async () => {
						n.hasAttribute(S) ? n.removeAttribute(S) : (M(t, n, i, e, a, l, c, f), d?.addEventListener("ionKeyboardDidShow", w), t.addEventListener("focusout", p));
					};
					return t.addEventListener("focusin", m), () => {
						t.removeEventListener("focusin", m), d?.removeEventListener("ionKeyboardDidShow", w), t.removeEventListener("focusout", p);
					};
				})(t$2, i, c, l, w, y, v, f);
				K.set(t$2, n);
			}
		}
	};
	b && (() => {
		let o = !0, t = !1;
		const n = document;
		u$1(n, "ionScrollStart", (() => {
			t = !0;
		})), n.addEventListener("focusin", (() => {
			o = !0;
		}), !0), n.addEventListener("touchend", ((i) => {
			if (t) return void (t = !1);
			const e = n.activeElement;
			if (!e) return;
			if (e.matches(p)) return;
			const a = i.target;
			a !== e && (a.matches(p) || a.closest(p) || (o = !1, setTimeout((() => {
				o || e.blur();
			}), 50)));
		}), !1);
	})();
	for (const o of D) k(o);
	o.addEventListener("ionInputDidLoad", ((o) => {
		k(o.detail);
	})), o.addEventListener("ionInputDidUnload", ((o) => {
		((o) => {
			if (h) {
				const t = x.get(o);
				t && t(), x.delete(o);
			}
			if (m) {
				const t = K.get(o);
				t && t(), K.delete(o);
			}
		})(o.detail);
	}));
};
//#endregion
export { x as startInputShims };
