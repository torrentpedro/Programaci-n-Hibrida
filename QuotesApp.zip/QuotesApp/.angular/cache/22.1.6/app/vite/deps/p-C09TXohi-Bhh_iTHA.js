import { f as d$1 } from "./p-1sJ0ZDPe-Ppa1imUr.js";
//#region node_modules/@ionic/core/components/p-Dojwmvde.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var r$1 = (r) => {
	for (let t = r; t; t = t.parentElement) {
		const r = t.getAttribute("dir")?.toLowerCase();
		if ("rtl" === r) return !0;
		if ("ltr" === r) return !1;
	}
	return "rtl" === document?.dir?.toLowerCase();
};
//#endregion
//#region node_modules/@ionic/core/components/p-C09TXohi.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var r = (a, i = 0) => new Promise(((r) => {
	e(a, i, r);
}));
var e = (a, i = 0, r) => {
	let e, t;
	const n = { passive: !0 }, o = () => {
		e && e();
	}, s = (i) => {
		void 0 !== i && a !== i.target || (o(), r(i));
	};
	return a && (a.addEventListener("webkitTransitionEnd", s, n), a.addEventListener("transitionend", s, n), t = setTimeout(s, i + 500), e = () => {
		void 0 !== t && (clearTimeout(t), t = void 0), a.removeEventListener("webkitTransitionEnd", s, n), a.removeEventListener("transitionend", s, n);
	}), o;
};
var t = (a, i) => {
	a.componentOnReady ? a.componentOnReady().then(((a) => i(a))) : m((() => i(a)));
};
var n = (a) => void 0 !== a.componentOnReady;
var o = (a, i = []) => {
	const r = {};
	return i.forEach(((i) => {
		a.hasAttribute(i) && (null !== a.getAttribute(i) && (r[i] = a.getAttribute(i)), a.removeAttribute(i));
	})), r;
};
var s = [
	"role",
	"aria-activedescendant",
	"aria-atomic",
	"aria-autocomplete",
	"aria-braillelabel",
	"aria-brailleroledescription",
	"aria-busy",
	"aria-checked",
	"aria-colcount",
	"aria-colindex",
	"aria-colindextext",
	"aria-colspan",
	"aria-controls",
	"aria-current",
	"aria-describedby",
	"aria-description",
	"aria-details",
	"aria-disabled",
	"aria-errormessage",
	"aria-expanded",
	"aria-flowto",
	"aria-haspopup",
	"aria-hidden",
	"aria-invalid",
	"aria-keyshortcuts",
	"aria-label",
	"aria-labelledby",
	"aria-level",
	"aria-live",
	"aria-multiline",
	"aria-multiselectable",
	"aria-orientation",
	"aria-owns",
	"aria-placeholder",
	"aria-posinset",
	"aria-pressed",
	"aria-readonly",
	"aria-relevant",
	"aria-required",
	"aria-roledescription",
	"aria-rowcount",
	"aria-rowindex",
	"aria-rowindextext",
	"aria-rowspan",
	"aria-selected",
	"aria-setsize",
	"aria-sort",
	"aria-valuemax",
	"aria-valuemin",
	"aria-valuenow",
	"aria-valuetext"
];
var l = (a) => o(a, s);
var u = (a, i, r, e) => a.addEventListener(i, r, e);
var d = (a, i, r, e) => a.removeEventListener(i, r, e);
var c = (a, i = a) => a.shadowRoot || i;
var m = (a) => "function" == typeof __zone_symbol__requestAnimationFrame ? __zone_symbol__requestAnimationFrame(a) : "function" == typeof requestAnimationFrame ? requestAnimationFrame(a) : setTimeout(a);
var p = (a) => !!a.shadowRoot && !!a.attachShadow;
var f = (a) => {
	if (a.focus(), a.classList.contains("ion-focusable")) {
		const i = a.closest("ion-app");
		i && i.setFocus([a]);
	}
};
var b = (a, i, r, e, t) => {
	{
		let a = i.querySelector("input.aux-input");
		a || (a = i.ownerDocument.createElement("input"), a.type = "hidden", a.classList.add("aux-input"), i.appendChild(a)), a.disabled = t, a.name = r, a.value = e || "";
	}
};
var v = (a, i, r) => Math.max(a, Math.min(i, r));
var w = (i, r) => {
	if (!i) {
		const i = "ASSERT: " + r;
		throw d$1(i), new Error(i);
	}
};
var x = (a) => {
	if (a) {
		const i = a.changedTouches;
		if (i && i.length > 0) {
			const a = i[0];
			return {
				x: a.clientX,
				y: a.clientY
			};
		}
		if (void 0 !== a.pageX) return {
			x: a.pageX,
			y: a.pageY
		};
	}
	return {
		x: 0,
		y: 0
	};
};
var y = (a, r) => {
	const e = r$1(r);
	switch (a) {
		case "start": return e;
		case "end": return !e;
		default: throw new Error(`"${a}" is not a valid value for [side]. Use "start" or "end" instead.`);
	}
};
var h = (a, i) => {
	const r = a._original || a;
	return {
		_original: a,
		emit: _(r.emit.bind(r), i)
	};
};
var _ = (a, i = 0) => {
	let r;
	return (...e) => {
		clearTimeout(r), r = setTimeout(a, i, ...e);
	};
};
var T = (a, i) => {
	if (a ??= {}, i ??= {}, a === i) return !0;
	const r = Object.keys(a);
	if (r.length !== Object.keys(i).length) return !1;
	for (const e of r) {
		if (!(e in i)) return !1;
		if (a[e] !== i[e]) return !1;
	}
	return !0;
};
var j = (a) => "number" == typeof a && !isNaN(a) && isFinite(a);
//#endregion
export { w as _, f as a, r$1 as b, l as c, o as d, p as f, v as g, u as h, d as i, m as l, t as m, b as n, h as o, r as p, c as r, j as s, T as t, n as u, x as v, y };
