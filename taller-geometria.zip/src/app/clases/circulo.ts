// permite utilizar la Clase Padre
import { FiguraGeometrica } from './figura-geometrica';
// la clase Circulo hereda de la clase FiguraGeometrica
export class Circulo extends FiguraGeometrica {
   // acá permite guardar el redio del circulo
  constructor(private radio: number) {
    super();
  }

  calcularPerimetro(): number {
    return 2 * Math.PI * this.radio;
  }

}