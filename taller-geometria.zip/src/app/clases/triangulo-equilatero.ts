// permite utilizar la Clase Padre
import { FiguraGeometrica } from './figura-geometrica';
// la clase TrianguloEquilatero hereda de la clase FiguraGeometrica
export class TrianguloEquilatero extends FiguraGeometrica {

  constructor(private lado: number) {
    super();
  }

  calcularPerimetro(): number {
    return this.lado * 3;
  }

}