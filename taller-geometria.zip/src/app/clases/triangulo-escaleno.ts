// permite utilizar la Clase Padre
import { FiguraGeometrica } from './figura-geometrica';
// la clase TrianguloEscaleno hereda de la clase FiguraGeometrica
export class TrianguloEscaleno extends FiguraGeometrica {
// acá recibe los tres lados del triangulo
  constructor(
    private ladoA: number,
    private ladoB: number,
    private ladoC: number
  ) {
    super();
  }
  // Metodo de la clase padre sumando los 3 lados del triangulo
  calcularPerimetro(): number {
    return this.ladoA + this.ladoB + this.ladoC;
  }

}