import { Component } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardTitle,
  IonImg,
  IonItem,
  IonLabel,
  IonInput,
  IonButton,
  IonText
} from '@ionic/angular/standalone';

import { TrianguloEscaleno } from '../../clases/triangulo-escaleno';

@Component({
  selector: 'app-triangulo',
  templateUrl: './triangulo.component.html',
  styleUrls: ['./triangulo.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    DecimalPipe,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardTitle,
    IonImg,
    IonItem,
    IonLabel,
    IonInput,
    IonButton,
    IonText
  ]
})
export class TrianguloComponent {

  ladoA: number = 0;
  ladoB: number = 0;
  ladoC: number = 0;

  perimetro: number = 0;

  mostrarResultado: boolean = false;

  calcularPerimetro(): void {

    const triangulo = new TrianguloEscaleno(
      this.ladoA,
      this.ladoB,
      this.ladoC
    );

    this.perimetro = triangulo.calcularPerimetro();

    this.mostrarResultado = true;
  }

}