import { Component } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

import {
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardTitle,
  IonImg,
  IonItem,
  IonLabel,
  IonInput,
  IonButton,
  IonText
} from '@ionic/angular/standalone';

import { Circulo } from '../../clases/circulo';

@Component({
  selector: 'app-circulo',
  templateUrl: './circulo.component.html',
  styleUrls: ['./circulo.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    DecimalPipe,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardTitle,
    IonImg,
    IonItem,
    IonLabel,
    IonInput,
    IonButton,
    IonText
  ]
})
export class CirculoComponent {

  radio: number = 0;
  perimetro: number = 0;
  mostrarResultado: boolean = false;

  calcularPerimetro(): void {
    const circulo = new Circulo(this.radio);

    this.perimetro = circulo.calcularPerimetro();

    this.mostrarResultado = true;
  }

}